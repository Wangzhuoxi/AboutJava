package com.neunn.hotnews

import com.neunn.domain.NewsInfo
import com.neunn.server.HotNewsSearchServer
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{Result, Scan}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.SparkContext
import org.apache.spark.sql.{SQLContext, DataFrame, SparkSession}

import scala.collection.JavaConversions.bufferAsJavaList
import scala.collection.mutable.ListBuffer

object SearchBySpark {

  var sparkSession: SparkSession = null
  var sparkContext: SparkContext = null
  var sqlContext: SQLContext = null
  var scoreSchema: DataFrame = null

  // 初始化spark
  def sparkInit(): Unit = {
    try {
      // 配置spark
      this.sparkSession = SparkSession.builder()
        .master("spark://192.168.159.129:7077")
        .appName("HotNewsSearch")
        .config("spark.executor.memory", "20g")
        .config("spark.cores.max", "16")
        .config("spark.sql.warehouse.dir", "/home/hdfs/software/spark")
        .getOrCreate()
      this.sparkContext = this.sparkSession.sparkContext
      this.sqlContext = this.sparkSession.sqlContext
    } catch {
      case ex: Exception => {
        throw new Exception(ex) // 异常重新抛出
      }
    }
  }

  def getHotNewsByTitle(sql: String, sqlTableName: String, isCache: Boolean, readFromCache: Boolean): java.util.List[String] = {
    // 从缓存中获取结果
    if (readFromCache) {
      println("从缓存获取的结果")
      val result_1 = sqlContext.sql(sql) // 通过sqlContext执行SQL语句查询
      result_1.show()
      return extractNews(result_1)
    }

    // 配置连接的Hbase
    val hbaseConf = HBaseConfiguration.create()
    hbaseConf.set("hbase.zookeeper.quorum", "192.168.159.129, 192.168.159.130, 192.168.159.131")
    hbaseConf.set(TableInputFormat.INPUT_TABLE, "public_opinion:metadata")

    val hbaseRDD = sparkContext.newAPIHadoopRDD(hbaseConf,
      classOf[TableInputFormat],
      classOf[ImmutableBytesWritable],
      classOf[Result])

    // 构造新闻对象体
    val hbaseInfo = hbaseRDD.map(resultTuple2 => {
      val newsInfo = new NewsInfo()
      newsInfo.setNewsTime(Bytes.toString(resultTuple2._2.getValue(Bytes.toBytes("f2"), Bytes.toBytes("timestamp"))))
      newsInfo.setNewsTitle(Bytes.toString(resultTuple2._2.getValue(Bytes.toBytes("f2"), Bytes.toBytes("title"))))
      newsInfo.setNewsUrl(Bytes.toString(resultTuple2._2.getValue(Bytes.toBytes("f2"), Bytes.toBytes("url"))))
      newsInfo
    })

    // 获取DataFrame
    scoreSchema = sqlContext.createDataFrame(hbaseInfo, classOf[NewsInfo])

    // 加入缓存中
    if (isCache) {
      scoreSchema.cache()
    }

    scoreSchema.createOrReplaceTempView(sqlTableName) // 创建临时视图，生命周期同sparkSession相同

    val result = sqlContext.sql(sql)
    result.show()
    extractNews(result)
  }

  // 根据查询到的DataFrame提取新闻
  def extractNews(newsDF: DataFrame): java.util.List[String] = {
    val resultList = new ListBuffer[String]()
    var newsSource = ""
    // 通过URL确定新闻来源
    for (news <- newsDF.collect()) { //collect()把DF转为Array,不加则resultList一直为[]
      news(2).toString match {
        case _ if (news(2).toString.indexOf("sohu.com") != -1) => newsSource = "搜狐网"
        case _ if (news(2).toString.indexOf("sina.com") != -1) => newsSource = "新浪网"
        case _ if (news(2).toString.indexOf("qq.com") != -1) => newsSource = "腾讯网"
        case _ if (news(2).toString.indexOf("163.com") != -1) => newsSource = "网易新闻"
        case _ if (news(2).toString.indexOf("cri.cn") != -1) => newsSource = "国际在线"
        case _ if (news(2).toString.indexOf("wenweipo.com") != -1) => newsSource = "文汇网"
        case _ if (news(2).toString.indexOf("caixin.com") != -1) => newsSource = "财新网"
        case _ if (news(2).toString.indexOf("stnn.cc") != -1) => newsSource = "星岛环球网"
        case _ if (news(2).toString.indexOf("chinanews.com") != -1) => newsSource = "中国新闻网"
        case _ if (news(2).toString.indexOf("people.com") != -1) => newsSource = "人民网"
        case _ if (news(2).toString.indexOf("cctv.com") != -1) => newsSource = "央视网"
        case _ if (news(2).toString.indexOf("cankaoxiaoxi.com") != -1) => newsSource = "参考消息"
        case _ if (news(2).toString.indexOf("china.com") != -1) => newsSource = "中华网"
        case _ if (news(2).toString.indexOf("xinhuanet.com") != -1) => newsSource = "新华网"
        case _ if (news(2).toString.indexOf("bjnews.com") != -1) => newsSource = "新京报"
        case _ if (news(2).toString.indexOf("cyol.com") != -1) => newsSource = "中青在线"
        case _ if (news(2).toString.indexOf("gmw.cn") != -1) => newsSource = "光明网"
        case _ if (news(2).toString.indexOf("cnr.cn") != -1) => newsSource = "央广网"
        case _ => newsSource = "其他"
      }
      resultList.append(news(0) + "$$$$$$" + newsSource + "$$$$$$" + news(2) + "$$$$$$" + news(1)) // 信息添加到list中
    }
    resultList.distinct //去重
  }

  // 主函数
  def main(args: Array[String]): Unit = {
    sparkInit()

    val timeInterval = 1000 * 60 * 20
    val tableName: String = "metadata"
    val initSql = "SELECT * from " + tableName
    val server = new HotNewsSearchServer

    getHotNewsByTitle(initSql, tableName, true, false)

    // 工作线程
    val runnable = new Runnable {
      override def run(): Unit = {
        while (true) {
          try {
            Thread.sleep(timeInterval)  // 每隔20分钟刷新一次DF
          } catch {
            case e: InterruptedException => e.printStackTrace()
          }
          getHotNewsByTitle(initSql, tableName, true, false)
        }
      }
    }

    val thread = new Thread(runnable)
    thread.start()

    server.startServer()
  }
}
