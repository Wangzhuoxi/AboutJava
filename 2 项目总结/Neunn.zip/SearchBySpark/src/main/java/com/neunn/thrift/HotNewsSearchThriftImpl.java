package com.neunn.thrift;

import com.neunn.hotnews.SearchBySpark;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.htrace.fasterxml.jackson.core.JsonProcessingException;
import org.apache.htrace.fasterxml.jackson.databind.ObjectMapper;
import org.apache.thrift.TException;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

// Thrift的实现类，Processor指定的具体实现逻辑
public class HotNewsSearchThriftImpl implements HotNewsSearchResultThrift.Iface {

    @Override
    // 返回查询的结果
    public List<String> showSearchResult(String keyword) throws TException {

        List<String> resultList = new ArrayList<String>();
        if (keyword.equals("")) {
            return readAllNewsFromFile();   // 未指定关键词就读取全部新闻
        }

        Date now = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String searchTime = df.format(now);
        System.out.println(searchTime + " " + "\"" + keyword + "\"");
        String sql = "SELECT * from metadata WHERE newsTitle LIKE \'%" + keyword + "%\'";   //查询语句
        List<String> list = SearchBySpark.getHotNewsByTitle(sql, "metadata", false, true);  //spark执行查询

        JSONArray newsJson = new JSONArray();

        //来源统计
        HashMap<String, Integer> sourceMap = sourceMapInit();
        Integer sourceCount;

        //时间统计
        Date today = new Date();
        HashMap<String, Integer> timeMap = timeMapInit();
        Integer timeCount;

        int newsCount = 0;

        for (String line : list) {
            //最多只展示100条新闻
            if (newsCount < 100) {
                JSONObject member = new JSONObject();
                member.put("time", line.split("\\$\\$\\$\\$\\$\\$")[0]);
                member.put("source", line.split("\\$\\$\\$\\$\\$\\$")[1]);
                member.put("url", line.split("\\$\\$\\$\\$\\$\\$")[2]);
                member.put("title", line.split("\\$\\$\\$\\$\\$\\$")[3]);
                newsJson.add(member);
                newsCount++;
            }

            //来源统计
            sourceCount = sourceMap.get(line.split("\\$\\$\\$\\$\\$\\$")[1]);
            sourceCount = sourceCount + 1;
            sourceMap.put(line.split("\\$\\$\\$\\$\\$\\$")[1], sourceCount);

            //时间统计
            DateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date newsTime = null;
            try {
                newsTime = timeFormat.parse(line.split("\\$\\$\\$\\$\\$\\$")[0]);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if ((today.getTime() - newsTime.getTime()) / (1000 * 3600 * 24) <= 7) {
                timeCount = timeMap.get(line.split("\\$\\$\\$\\$\\$\\$")[0]);
                timeCount = timeCount + 1;
                timeMap.put(line.split("\\$\\$\\$\\$\\$\\$")[0], timeCount);
            }

        }
        //若来源数>=10则sourceMap数为实际来源数量；若来源数<10则为10(随机用来源数为0的来源填充)
        Collection<Integer> col = sourceMap.values();
        int deleteNum = 9;
        while (deleteNum > 0) {
            col.remove(0);
            deleteNum--;
        }

        //timeMap时间由小到大排序
        ObjectMapper mapper = new ObjectMapper();

        try {
            String newsList = newsJson.toString();
            String newsSource = mapper.writeValueAsString(sourceMap);
            String newsTime = mapper.writeValueAsString(timeMap);
            String newsNum = "{\"新闻信息量\":" + list.size() + "}";
            String newsChange = "{\"热度同比\":\"" + calaNewsChange(timeMap) + "\"}";

            resultList.add(newsList);
            resultList.add(newsSource);
            resultList.add(newsTime);
            resultList.add(newsNum);
            resultList.add(newsChange);

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return resultList;
    }

    //初始化来源统计Map(让来源只能是初始化中的)
    public HashMap<String, Integer> sourceMapInit() {
        HashMap<String, Integer> sourceMap = new HashMap();
        sourceMap.put("搜狐网", 0);
        sourceMap.put("新浪网", 0);
        sourceMap.put("腾讯网", 0);
        sourceMap.put("网易新闻", 0);
        sourceMap.put("中华网", 0);
        sourceMap.put("星岛环球网", 0);
        sourceMap.put("国际在线", 0);
        sourceMap.put("文汇网", 0);
        sourceMap.put("财新网", 0);
        sourceMap.put("中国新闻网", 0);
        sourceMap.put("中青在线", 0);
        sourceMap.put("央视网", 0);
        sourceMap.put("新华网", 0);
        sourceMap.put("参考消息", 0);
        sourceMap.put("新京报", 0);
        sourceMap.put("央广网", 0);
        sourceMap.put("光明网", 0);
        sourceMap.put("人民网", 0);
        sourceMap.put("其他", 0);

        return sourceMap;
    }

    //初始化时间统计Map（让时间只能是最近一周）
    public LinkedHashMap<String, Integer> timeMapInit() {

        LinkedHashMap<String, Integer> timeMap = new LinkedHashMap();

        Calendar cal_7 = Calendar.getInstance();
        cal_7.add(Calendar.DATE, -7);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_7.getTime()), 0);

        Calendar cal_6 = Calendar.getInstance();
        cal_6.add(Calendar.DATE, -6);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_6.getTime()), 0);

        Calendar cal_5 = Calendar.getInstance();
        cal_5.add(Calendar.DATE, -5);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_5.getTime()), 0);

        Calendar cal_4 = Calendar.getInstance();
        cal_4.add(Calendar.DATE, -4);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_4.getTime()), 0);

        Calendar cal_3 = Calendar.getInstance();
        cal_3.add(Calendar.DATE, -3);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_3.getTime()), 0);

        Calendar cal_2 = Calendar.getInstance();
        cal_2.add(Calendar.DATE, -2);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_2.getTime()), 0);

        Calendar cal_1 = Calendar.getInstance();
        cal_1.add(Calendar.DATE, -1);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_1.getTime()), 0);

        Date today = new Date();
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(today), 0);

        return timeMap;
    }

    //计算热度同比
    public String calaNewsChange(HashMap<String, Integer> timeMap) {
        String toDay = new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
        Calendar cal_1 = Calendar.getInstance();
        cal_1.add(Calendar.DATE, -1);
        String yesDay = new SimpleDateFormat("yyyy-MM-dd").format(cal_1.getTime());
        //System.out.println(timeMap.get(toDay) + "   " + timeMap.get(yesDay));
        if (timeMap.get(yesDay) == 0) {
            return "--";
        }
        //计算现在的小时数
        Date now = new Date();
        SimpleDateFormat df = new SimpleDateFormat("HH");
        String hourNumStr = df.format(now);
        float hourNum = Integer.parseInt(hourNumStr);
        //System.out.println(24/hourNum);
        //估算今天一天的新闻量并计算变化量
        float change = (float) ((timeMap.get(toDay) * (24 / (hourNum + 0.5)) - timeMap.get(yesDay)) / (timeMap.get(yesDay)));
        NumberFormat nt = NumberFormat.getPercentInstance();
        nt.setMinimumFractionDigits(0);
        //System.out.println(change);

        return nt.format(change);
    }


    @Override
    // thrift接口，返回热词
    public String showKeywords(boolean action) {
        String keywordsResult = new String();
        if (action) {
            keywordsResult = readKeywordsFromFile();
        }
        return keywordsResult;
    }

    // 从本地文件读取热词（本地文件通过定时任务生成）
    public String readKeywordsFromFile() {
        JSONObject keywordsJson = new JSONObject();
        try {
            FileReader reader = new FileReader("/home/hdfs/sparkApp/hotNews/HotKeyWords/HotKeyWords.txt");  //获取本地文件
            BufferedReader br = new BufferedReader(reader);

            String line;
            while ((line = br.readLine()) != null) {
                keywordsJson.put(line.split(",")[0], Integer.parseInt(line.split(",")[1])); //读取关键词文件并存入json
            }

            br.close();
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return keywordsJson.toString();
    }

    @Override
    public void refreshDF(boolean action) {
        if (action) {
            SearchBySpark.getHotNewsByTitle("SELECT * from metadata", "metadata", true, false);
        }
    }

    // 全局新闻（未指定关键词的新闻）通过读取本地文件得到（本地文件由定时任务产生）
    public List<String> readAllNewsFromFile() {

        List<String> news = new ArrayList<String>();
        try {
            FileReader reader = new FileReader("/home/hdfs/sparkApp/hotNews/HotKeyWords/AllNews.txt");
            BufferedReader br = new BufferedReader(reader);

            String line;
            try {
                while ((line = br.readLine()) != null) {
                    news.add(line); //将结果存入List
                }
                br.close();
                reader.close();
            }catch (IOException e) {
                e.printStackTrace();
            }

        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return news;
    }
}
