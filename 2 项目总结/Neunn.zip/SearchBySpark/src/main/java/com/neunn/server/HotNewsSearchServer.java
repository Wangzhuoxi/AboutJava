package com.neunn.server;

import com.neunn.thrift.HotNewsSearchResultThrift;
import com.neunn.thrift.HotNewsSearchThriftImpl;
import org.apache.thrift.TProcessor;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadPoolServer;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TServerSocket;

// Thrift服务端
public class HotNewsSearchServer {

    public void startServer() {
        try {
            // 创建Processor处理器（对请求做出响应，具体的处理逻辑在HotNewsSearchThriftImpl中）
            TProcessor tProcessor = new HotNewsSearchResultThrift.Processor(new HotNewsSearchThriftImpl());

            // 创建Transport传输层
            TServerSocket tServerSocket = new TServerSocket(8896);

            // Server的参数配置（线程池类型的server）
            TThreadPoolServer.Args ttpsArgs = new TThreadPoolServer.Args(tServerSocket);    //设置server的传输transport
            ttpsArgs.processor(tProcessor); // 设置server的处理器processor
            ttpsArgs.transportFactory(new TFramedTransport.Factory());
            ttpsArgs.protocolFactory(new TBinaryProtocol.Factory());    //设置Protocol二进制协议

            System.out.println("=================SearchBySpark-ThriftServer服务启动=================");

            // 线程池服务模型，使用标准的阻塞式IO，预先创建一组线程处理请求。
            TServer tServer = new TThreadPoolServer(ttpsArgs);
            tServer.serve();

        } catch (Exception e) {
            System.out.println("Server start error!");
            e.printStackTrace();
        }
    }

    // 主函数测试
    public static void main(String[] args) {
        HotNewsSearchServer server = new HotNewsSearchServer();
        server.startServer();
    }
}
