import com.neunn.thrift.HotNewsSearchResultThrift;
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

import java.util.List;

public class SearchClientDemo {

    public void startClient(String userName) {
        TTransport transport = null;
        try {
            transport = new TSocket("localhost",8896, 300000);
            TTransport framesTrans = new TFramedTransport(transport);
            TProtocol protocol = new TBinaryProtocol(framesTrans);

            HotNewsSearchResultThrift.Client client = new HotNewsSearchResultThrift.Client(protocol);
            transport.open();

            // 查询新闻
            List<String> result = client.showSearchResult(userName);
            System.out.println(result.get(0));
            System.out.println(result.get(1));
            System.out.println(result.get(2));
            System.out.println(result.get(3));
            System.out.println(result.get(4));

            // 查询关键词
            String keywordsList = client.showKeywords(true);
            System.out.println(keywordsList);
            System.out.println();

        }catch (TTransportException e) {
            e.printStackTrace();
        }catch (TException e) {
            e.printStackTrace();
        }finally {
            if (transport != null) {
                transport.close();
            }
        }
    }

    // 测试主函数
    public static void main(String[] args) {
        SearchClientDemo client = new SearchClientDemo();

        long start = System.currentTimeMillis();

        client.startClient("");
        client.startClient("人类");
        client.startClient("金融");
        client.startClient("医生");
        client.startClient("青蛙");
        client.startClient("青蛙");
        client.startClient("万达");
        client.startClient("苹果");

        System.out.println("耗时：" + (System.currentTimeMillis() - start) + "毫秒");
    }
}
