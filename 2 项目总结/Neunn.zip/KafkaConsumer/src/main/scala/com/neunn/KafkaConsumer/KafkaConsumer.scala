package com.neunn.KafkaConsumer

import java.text.SimpleDateFormat
import java.util.concurrent._
import java.util.{Date, Properties}

import com.neunn.MD5.MessageMD5
import kafka.consumer.{Consumer, ConsumerConfig, KafkaStream}
import kafka.utils.Logging
import org.apache.hadoop.hbase.client.{ConnectionFactory, Put}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}

import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import scala.util.matching.Regex
import scala.util.parsing.json.JSON

// kafka消费者
class KafkaConsumer(val zookeeper: String,
                    val groupId: String,
                    val topic: String,
                    val zpHbase: String,
                    val tbName: String,
                    val contentMinSize: String,
                    val regexFilePath: String,
                    val filePath: String) extends Logging {


  val config = createConsumerConfig(zookeeper, groupId) // 配置文件
  val consumer = Consumer.create(config)  // 消费者
  var executor: ExecutorService = null    // 线程

  // 关闭操作
  def shutdown() = {
    if (consumer != null) //关闭消费者
      consumer.shutdown()
    if (executor != null) //关闭消费者线程
      executor.shutdown()
  }

  // 根据参数生成消费者配置
  def createConsumerConfig(zookeeper: String, groupId: String): ConsumerConfig = {
    val props = new Properties() //属性配置（键值对）
    props.put("zookeeper.connect", zookeeper) //zookeeper连接串
    props.put("group.id", groupId)  //组ID，相同id的consumer属于同一个组
    props.put("auto.offset.reset", "largest") //自动将偏移重置为最大偏移
    props.put("zookeeper.session.timeout.ms", "400") //ZooKeeper会话超时
    props.put("zookeeper.sync.time.ms", "200") //zk follower落后于zk leader的最长时间
    props.put("auto.commit.interval.ms", "1000") //消费者offset提交到zookeeper的频率（毫秒）
    val config = new ConsumerConfig(props)
    config
  }

  // 运行线程
  def run(numThreads: Int) = {

    val topicCountMap = Map(topic -> numThreads)  //读取的topic以及对应的消费线程数
    val consumerMap = consumer.createMessageStreams(topicCountMap)  //创建Streams
    val streams = consumerMap.get(topic).get  //每个线程对应于一个KafkaStream

    executor = Executors.newFixedThreadPool(numThreads) //固定数量的线程池

    var threadNumber = 0  //运行的线程id
    for (stream <- streams) {
      // 利用多线程处理获取到的数据流
      executor.submit(new ScalaConsumerTest(stream, threadNumber, zpHbase, tbName, contentMinSize, regexFilePath, filePath))
      threadNumber += 1
    }
  }
}

// scala中表示静态方法和属性
object ScalaConsumerExample extends App {

  // 参数错误
  if (args.length < 9) {
    System.err.println("Usage: KafkaConsumer <zkQuorum> <group> <topic> <numThreads> <zkHbase> <tableName> <contentMinSize> <regexFilePath> <filePath>")
    System.exit(1)
  }

  // 根据参数创建消费者并运行
  val Array(zkQuorum, group, topic, numThreads, zkHbase, tableName, contentMinSize, regexFilePath, filePath) = args
  val example = new KafkaConsumer(zkQuorum, group, topic, zkHbase, tableName, contentMinSize, regexFilePath, filePath)
  example.run(numThreads.toInt)

}

// 运行线程类（处理从kafka中接收到的数据，处理后存入HBase数据库）
class ScalaConsumerTest(val stream: KafkaStream[Array[Byte], Array[Byte]],  //Kafka数据流
                        val threadNumber: Int,  // 线程ID
                        val zpHbase: String,    // Hbase的zookeeper信息
                        val tbName: String,     // 用户表名
                        val contentMinSize: String, //新闻内容的最小大小
                        val regexFilePath: String,  //正则文件的路径
                        val filePath: String) extends Logging with Runnable {

  def run {
    val regexforTitle = new StringBuilder() //title的正则表达式
    val linesList = Source.fromFile(regexFilePath).getLines.toList //获取文件并转成List

    // 根据文件构造正则表达式，并用|分隔
    for (line <- linesList){
      if(line != ""){
        if(line != linesList(linesList.size - 1)){
          regexforTitle.append(line + "|")
        }else{
          regexforTitle.append(line)
        }
      }
    }

    val patternForTitle = new Regex(regexforTitle.toString) // 标题正则
    val df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") // 时间格式
    val patternForUrl = new Regex("_\\d{1,2}.[a-z]+|_p\\d{1,2}.[a-z]+") // url正则
    val it = stream.iterator()  // 获取stream的迭代器

    val conf = HBaseConfiguration.create()  // HBase配置（资源中的hbase配置文件）
    conf.set("hbase.zookeeper.quorum", zpHbase) //设置zookeeper节点
    val connection = ConnectionFactory.createConnection(conf) //建立连接

    val userTable = TableName.valueOf(tbName)
    val table = connection.getTable(userTable)  //获取用户表

    // 迭代数据流
    while (it.hasNext()) {
      val msg = new String(it.next().message()) // 获取到的数据信息

      val fileName = new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + ".txt" //记录文件
      println(fileName + " -> " + msg)

      val jsonObj = JSON.parseFull(msg) // 数据转换成json格式
      val map: Map[String, Any] = jsonObj.get.asInstanceOf[Map[String, Any]]  // json数据存入map（键值对）

      val urlFilterList = scala.collection.mutable.Set[String]()  // 过滤url的可变集合

      if((patternForUrl findAllIn map.get("url").get.toString).isEmpty){  // url为空
        if(map.get("bodys").get.toString.size > contentMinSize.toInt){  // 内容超过最小大小（有效）
          if(!urlFilterList.contains(map.get("url").get.toString)){ //没有遇到过的url
            urlFilterList.add(map.get("url").get.toString) // 加入到过滤集合中

            // MD5加密URL后作为行ID（避免重复）
            val urlmd5 = new MessageMD5().messageMD5(map.get("url").get.toString) //url的md5加密
            val rowKey = new ArrayBuffer[Byte]()
            rowKey ++= Bytes.toBytes(-new Date().getTime) //写入日期
            rowKey ++= Bytes.toBytes(urlmd5)  //写入加密后的url

            try {
              val p = new Put(rowKey.toArray) // 构造插入数据的Put对象
              p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("content"), Bytes.toBytes(map.get("bodys").get.toString))  // 添加新闻内容
              p.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("url"), Bytes.toBytes(map.get("url").get.toString))        // 添加URL
              p.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("timestamp"), Bytes.toBytes(map.get("time").get.toString)) // 添加时间

              var orgTitle = map.get("title").get.toString  //获取新闻标题
              while(!(patternForTitle findAllIn orgTitle).isEmpty){ // 如果标题前面的发言者（正则文件中定义）不为空，把他们置为空
                orgTitle = patternForTitle replaceFirstIn(orgTitle, "")
              }
              p.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("title"), Bytes.toBytes(orgTitle)) //添加新闻标题
              table.put(p)  //存入表中

              println(df.format(new Date()) + ",Thread " + threadNumber + ": " + map.get("title").get.toString) // 输出线程ID和新闻标题
            } catch {
              case _: Exception => println(df.format(new Date()) + "raw error!")  //记录异常的日期
            }
          }
        }
      }

    }
    println(df.format(new Date()) + "Shutting down Thread: " + threadNumber)  //线程结束输出信息
  }

}