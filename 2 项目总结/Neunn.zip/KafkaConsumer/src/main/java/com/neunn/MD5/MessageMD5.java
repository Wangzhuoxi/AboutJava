package com.neunn.MD5;

import java.security.MessageDigest;

public class MessageMD5 {

    public MessageMD5(){

    }

    public String messageMD5(String message){
        char hexDigits[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        try {
            byte[] btInput = message.getBytes();
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInput); // 使用指定的字节更新摘要
            byte[] md = mdInst.digest();  // 获得密文
            // 把密文转换成十六进制的字符串形式
            int length = md.length;
            char str[] = new char[length * 2];
            int index = 0;
            for (int i = 0; i < length; i++) {
                byte byte0 = md[i]; // byte是8位
                str[index++] = hexDigits[byte0 >>> 4 & 0xf];    //取高4位
                str[index++] = hexDigits[byte0 & 0xf];//取低4位
            }
            return new String(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
