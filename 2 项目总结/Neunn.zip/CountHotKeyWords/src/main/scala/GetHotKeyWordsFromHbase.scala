import java.io.{File, FileNotFoundException, PrintWriter}
import java.util.{Calendar, Date}

import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.{ConnectionFactory, Scan, Table}
import org.apache.hadoop.hbase.util.Bytes

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object GetHotKeyWordsFromHbase {

  def getHotKeywords(table: Table, top: Int, time: String): mutable.LinkedHashMap[String, Int] = {

    // 设定查询的时间范围
    val cal = Calendar.getInstance()
    time match {
      case "Hour" => cal.add(Calendar.HOUR, -1) //1小时内
      case "Day" => cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0) //1天内
      case "Week" => cal.add(Calendar.DATE, -7) //7天内
      case "Month" => cal.add(Calendar.MONTH, -1) //1个月内
    }

    // 统计新闻的开始时间
    val startRowKey = new ArrayBuffer[Byte]()
    startRowKey ++= Bytes.toBytes(-1 * new Date().getTime)
    startRowKey ++= Bytes.toBytes("00000000000000000000000000000000")

    // 统计新闻的结束日期
    val stopRowKey = new ArrayBuffer[Byte]()
    stopRowKey ++= Bytes.toBytes(-1 * cal.getTime.getTime)
    stopRowKey ++= Bytes.toBytes("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF")

    // 根据时间设置扫描类Scan
    val s = new Scan()
    s.setStartRow(startRowKey.toArray)
    s.setStopRow(stopRowKey.toArray)

    s.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("keywords"))
    val scanner = table.getScanner(s)

    // 扫描Hbase并保存结果
    val wordsList = new ArrayBuffer[String]()
    var eachRow = scanner.next()
    while (eachRow != null) {
      wordsList.append(Bytes.toString(eachRow.getValue(Bytes.toBytes("f1"), Bytes.toBytes("keywords"))))
      eachRow = scanner.next()
    }
    scanner.close()

    // 统计关键词的频次
    var wordsMap = mutable.Map[String, Int]()
    wordsList.foreach(
      KeyWord => {
        wordsMap.contains(KeyWord) match {
          case true => wordsMap += (KeyWord -> (wordsMap.get(KeyWord).get + 1)) // 包含关键词则加1
          case false => wordsMap += (KeyWord -> 1) //不包含置1
        }
      }
    )

    //.toSeq把Map变成ArrayBuffer[Tuple](元组用._1访问第一个元素)
    val wordsArray = wordsMap.toSeq.sortWith(_._2 > _._2) //根据比较函数排序
    // 只保留前top个关键词
    val wordsArrayTop = wordsArray.dropRight(wordsArray.length - top)

    // LinkedHashMap为有序Map，若用Map则sort后仍为乱序
    val sortedMap = mutable.LinkedHashMap(wordsArrayTop: _*) //_*将集合的元素传入
    sortedMap
  }

  // 从Hbase数据库获取数据表
  def getTable(): Table = {
    val conf = HBaseConfiguration.create()
    conf.set("hbase.zookeeper.quorum", "192.168.159.129, 192.168.159.130, 192.168.159.131")
    val conn = ConnectionFactory.createConnection(conf)
    val usrTable = TableName.valueOf("public_opinion:metadata")
    val table = conn.getTable(usrTable)
    table
  }

  // 将查询结果持久化
  def writeNewsToFile(keywordsMap: mutable.LinkedHashMap[String, Int]): Unit = {
    val filename: String = "E:\\IDEA Projects\\CountHotKeyWords"
    val writer: PrintWriter = new PrintWriter(new File(filename))

    keywordsMap.foreach(e => {
      writer.println(e.toString().replace("(", "").replace(")", "")) //替换括号字符
    })
    writer.close()
  }

  // 主函数测试
  def main(args: Array[String]): Unit = {
    val start: Long = System.currentTimeMillis()
    writeNewsToFile(getHotKeywords(getTable(), 50, "Week"))
    System.out.println("耗时：" + (System.currentTimeMillis() - start) + "毫秒")
  }
}
