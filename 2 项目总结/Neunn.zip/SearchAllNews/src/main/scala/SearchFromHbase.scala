import org.apache.hadoop.hbase.client.{ConnectionFactory, Result, Scan, Table}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{RegexStringComparator, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.{Counter, Base64, Bytes}
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}

import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.collection.JavaConversions.bufferAsJavaList

object SearchFromHbase {

  def getHotNewsByTitle2(table: Table, time: String, word: String): java.util.List[String] = {

    val s = new Scan() //Hbase数据查询类
    s.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("keywords"))
    s.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("title"))
    s.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("url"))
    s.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("timestamp"))
    s.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("content"))

    // 匹配数据库中的新闻数据
    val comp = new RegexStringComparator(word)
    val scanFilter = new SingleColumnValueFilter(Bytes.toBytes("f2"), Bytes.toBytes("title"), CompareOp.EQUAL, comp) //单列值过滤器
    s.setFilter(scanFilter) //设置查询类的过滤器
    val scanner = table.getScanner(s) //scanner是客户端扫描接口

    // 结果存入middleList中
    val middleList = new ArrayBuffer[Result]()
    var result = scanner.next()
    while (result != null) {
      middleList.append(result)
      result = scanner.next()
    }

    // 遍历middleList并处理
    val resultList = new ListBuffer[String]()
    for (middleElement <- middleList) {
      try {
        // 获取各种信息值
        var getTitle = Bytes.toString(middleElement.getValue(Bytes.toBytes("f2"), Bytes.toBytes("title")))
        var getUrl = Bytes.toString(middleElement.getValue(Bytes.toBytes("f2"), Bytes.toBytes("url")))
        var getKeyword = Bytes.toString(middleElement.getValue(Bytes.toBytes("f1"), Bytes.toBytes("keywords")))
        var getTime = Bytes.toString(middleElement.getValue(Bytes.toBytes("f2"), Bytes.toBytes("timestamp")))
        var getContent = Bytes.toString(middleElement.getValue(Bytes.toBytes("f1"), Bytes.toBytes("content")))

        // 根据url确定新闻来源
        var getSource = ""
        getUrl match {
          case _ if (getUrl.indexOf("sohu.com") != -1) => getSource = "搜狐网"
          case _ if (getUrl.indexOf("sina.com") != -1) => getSource = "新浪网"
          case _ if (getUrl.indexOf("qq.com") != -1) => getSource = "腾讯网"
          case _ if (getUrl.indexOf("163.com") != -1) => getSource = "网易新闻"
          case _ if (getUrl.indexOf("cri.cn") != -1) => getSource = "国际在线"
          case _ if (getUrl.indexOf("wenweipo.com") != -1) => getSource = "文汇网"
          case _ if (getUrl.indexOf("caixin.com") != -1) => getSource = "财新网"
          case _ if (getUrl.indexOf("stnn.cc") != -1) => getSource = "星岛环球网"
          case _ if (getUrl.indexOf("chinanews.com") != -1) => getSource = "中国新闻网"
          case _ if (getUrl.indexOf("people.com") != -1) => getSource = "人民网"
          case _ if (getUrl.indexOf("cctv.com") != -1) => getSource = "央视网"
          case _ if (getUrl.indexOf("cankaoxiaoxi.com") != -1) => getSource = "参考消息"
          case _ if (getUrl.indexOf("china.com") != -1) => getSource = "中华网"
          case _ if (getUrl.indexOf("xinhuanet.com") != -1) => getSource = "新华网"
          case _ if (getUrl.indexOf("bjnews.com") != -1) => getSource = "新京报"
          case _ if (getUrl.indexOf("cyol.com") != -1) => getSource = "中青在线"
          case _ if (getUrl.indexOf("gmw.cn") != -1) => getSource = "光明网"
          case _ if (getUrl.indexOf("cnr.cn") != -1) => getSource = "央广网"
          case _ => getSource = "其他"
        }
        // 存入结果中
        if (getTitle != null && getKeyword != null && getUrl != null) {
          resultList.append(getTime + "$$$$$$" + getSource + "$$$$$$" + getKeyword + "$$$$$$" + getUrl + "$$$$$$" + getTitle + "$$$$$$" + getContent)
        }
      } catch {
        case ex: NullPointerException => {
          println("HBase中有脏数据！")
        }
      }
    }
    resultList.distinct //去除重复元素
  }

  // 效果和上方法一样（参数不同）
  def scanHbase(table: Table): java.util.List[String] = {

    val s = new Scan()
    s.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("keywords"))
    s.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("title"))
    s.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("url"))
    s.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("timestamp"))
    s.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("content"))

    val scanner = table.getScanner(s)

    val middleList = new ArrayBuffer[Result]()
    var result = scanner.next()

    while (result != null) {
      middleList.append(result)
      result = scanner.next()
    }

    val resultList = new ListBuffer[String]()
    for (middleElement <- middleList) {
      try {
        var getTitle = Bytes.toString(middleElement.getValue(Bytes.toBytes("f2"), Bytes.toBytes("title")))
        var getUrl = Bytes.toString(middleElement.getValue(Bytes.toBytes("f2"), Bytes.toBytes("url")))
        var getKeyword = Bytes.toString(middleElement.getValue(Bytes.toBytes("f1"), Bytes.toBytes("keywords")))
        var getTime = Bytes.toString(middleElement.getValue(Bytes.toBytes("f2"), Bytes.toBytes("timestamp")))
        var getContent = Bytes.toString(middleElement.getValue(Bytes.toBytes("f1"), Bytes.toBytes("content")))

        var getSource = ""
        getUrl match {
          case _ if (getUrl.indexOf("sohu.com") != -1) => getSource = "搜狐网"
          case _ if (getUrl.indexOf("sina.com") != -1) => getSource = "新浪网"
          case _ if (getUrl.indexOf("qq.com") != -1) => getSource = "腾讯网"
          case _ if (getUrl.indexOf("163.com") != -1) => getSource = "网易新闻"
          case _ if (getUrl.indexOf("cri.cn") != -1) => getSource = "国际在线"
          case _ if (getUrl.indexOf("wenweipo.com") != -1) => getSource = "文汇网"
          case _ if (getUrl.indexOf("caixin.com") != -1) => getSource = "财新网"
          case _ if (getUrl.indexOf("stnn.cc") != -1) => getSource = "星岛环球网"
          case _ if (getUrl.indexOf("chinanews.com") != -1) => getSource = "中国新闻网"
          case _ if (getUrl.indexOf("people.com") != -1) => getSource = "人民网"
          case _ if (getUrl.indexOf("cctv.com") != -1) => getSource = "央视网"
          case _ if (getUrl.indexOf("cankaoxiaoxi.com") != -1) => getSource = "参考消息"
          case _ if (getUrl.indexOf("china.com") != -1) => getSource = "中华网"
          case _ if (getUrl.indexOf("xinhuanet.com") != -1) => getSource = "新华网"
          case _ if (getUrl.indexOf("bjnews.com") != -1) => getSource = "新京报"
          case _ if (getUrl.indexOf("cyol.com") != -1) => getSource = "中青在线"
          case _ if (getUrl.indexOf("gmw.cn") != -1) => getSource = "光明网"
          case _ if (getUrl.indexOf("cnr.cn") != -1) => getSource = "央广网"
          case _ => getSource = "其他"
        }
        if (getTitle != null && getKeyword != null && getUrl != null) {
          resultList.append(getTime + "$$$$$$" + getSource + "$$$$$$" + getKeyword + "$$$$$$" + getUrl + "$$$$$$" + getTitle + "$$$$$$" + getContent)
        }
      } catch {
        case ex: NullPointerException => {
          println("HBase中有脏数据！")
        }
      }
    }
    resultList
  }

  // 连接Hbase并获取其中的数据表
  def getTable(): Table = {
    val conf = HBaseConfiguration.create() // Hbase配置文件
    conf.set("hbase.zookeeper.quorum", "192.168.159.129, 192.168.159.130, 192.168.159.131")
    val conn = ConnectionFactory.createConnection(conf)
    val usrTable = TableName.valueOf("public_opinion:metadata")
    val table = conn.getTable(usrTable)
    table
  }

  // 测试
  def main(args: Array[String]) {
    val start: Long = System.currentTimeMillis()
    println(scanHbase(getTable()).size())
    println("耗时：" + (System.currentTimeMillis() - start) + "毫秒")
  }
}
