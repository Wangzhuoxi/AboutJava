import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.htrace.fasterxml.jackson.core.JsonProcessingException;
import org.apache.htrace.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class SearchAllNews {

    public List<String> showSearchResult(String keyword) {

        Date now = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  // 时间格式
        String searchTime = df.format(now);
        System.out.println(searchTime + " " + keyword);
        List<String> list = SearchFromHbase.getHotNewsByTitle2(SearchFromHbase.getTable(), "all", keyword); // 查询结果表

        JSONArray jsonMembers = new JSONArray();    // 数据的json数组

        // 来源统计
        HashMap<String, Integer> sourceMap = sourceMapInit();
        Integer sourceCount;

        // 时间统计
        Date today = new Date();
        HashMap<String, Integer> timeMap = timeMapInit();
        Integer timeCount;

        // 遍历统计数据的来源和时间
        for (String line : list) {
            // 构建数据的json对象
            JSONObject member = new JSONObject();
            member.put("time", line.split("\\$\\$\\$\\$\\$\\$")[0]);    // 时间
            member.put("source", line.split("\\$\\$\\$\\$\\$\\$")[1]);  // 来源
            member.put("url", line.split("\\$\\$\\$\\$\\$\\$")[3]);     // URL
            member.put("title", line.split("\\$\\$\\$\\$\\$\\$")[4]);   // 标题

            jsonMembers.add(member);

            // 来源统计
            sourceCount = sourceMap.get(line.split("\\$\\$\\$\\$\\$\\$")[1]);
            sourceCount++;
            sourceMap.put(line.split("\\$\\$\\$\\$\\$\\$")[1], sourceCount);

            // 时间统计
            DateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date newsTime = null;
            try {
                newsTime = timeFormat.parse(line.split("\\$\\$\\$\\$\\$\\$")[0]);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            // 统计7天以内的新闻
            if ((today.getTime() - newsTime.getTime()) / (1000 * 3600 * 24) <= 7) {
                timeCount = timeMap.get(line.split("\\$\\$\\$\\$\\$\\$")[0]);
                timeCount++;
                timeMap.put(line.split("\\$\\$\\$\\$\\$\\$")[0], timeCount);
            }
        }

        // 若来源数>=10则sourceMap数为实际来源数量；若来源数<10则为10(随机用来源数为0的来源填充)
        Collection<Integer> col = sourceMap.values();
        int deleteNum = 9;
        while (deleteNum > 0) {
            col.remove(0);
            deleteNum--;
        }

        ObjectMapper mapper = new ObjectMapper();   // 用来将对象转换成json字符串

        List<String> resultList = new ArrayList<String>();  // 数据及统计结果

        try {
            // 只留100个news
            System.out.println(jsonMembers.size());
            for (int i = jsonMembers.size() - 1; i > 100; i--) {
                jsonMembers.remove(i);
            }
            String newsList = jsonMembers.toString();   // 新闻信息
            String newsSource = mapper.writeValueAsString(sourceMap);   // 来源统计
            String newsTime = mapper.writeValueAsString(timeMap);       // 时间统计
            String newsNum = "{\"新闻信息量\":" + list.size() + "}";     // 新闻信息量
            String newsChange = "{\"热度同比\":\"" + calaNewsChange(timeMap) + "\"}";   // 热度同比

            System.out.println(newsList);
            System.out.println(newsSource);
            System.out.println(newsTime);
            System.out.println(newsNum);
            System.out.println(newsChange);
            System.out.println();

            resultList.add(newsList);
            resultList.add(newsSource);
            resultList.add(newsTime);
            resultList.add(newsNum);
            resultList.add(newsChange);

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return resultList;
    }

    // 初始化新闻来源Map
    public HashMap<String, Integer> sourceMapInit() {
        HashMap<String, Integer> sourceMap = new HashMap<String, Integer>();

        sourceMap.put("搜狐网", 0);
        sourceMap.put("新浪网", 0);
        sourceMap.put("腾讯网", 0);
        sourceMap.put("网易新闻", 0);
        sourceMap.put("中华网", 0);
        sourceMap.put("星岛环球网", 0);
        sourceMap.put("国际在线", 0);
        sourceMap.put("文汇网", 0);
        sourceMap.put("财新网", 0);
        sourceMap.put("中国新闻网", 0);
        sourceMap.put("中青在线", 0);
        sourceMap.put("央视网", 0);
        sourceMap.put("新华网", 0);
        sourceMap.put("参考消息", 0);
        sourceMap.put("新京报", 0);
        sourceMap.put("央广网", 0);
        sourceMap.put("光明网", 0);
        sourceMap.put("人民网", 0);
        sourceMap.put("其他", 0);

        return sourceMap;
    }

    // 初始化时间统计Map
    public LinkedHashMap<String, Integer> timeMapInit() {
        LinkedHashMap<String, Integer> timeMap = new LinkedHashMap<String, Integer>();

        // 统计日期为7天内的新闻
        Calendar cal_7 = Calendar.getInstance();
        cal_7.add(Calendar.DATE, -7);   // 7天以前
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_7.getTime()), 0);

        Calendar cal_6 = Calendar.getInstance();
        cal_6.add(Calendar.DATE, -6);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_6.getTime()), 0);

        Calendar cal_5 = Calendar.getInstance();
        cal_5.add(Calendar.DATE, -5);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_5.getTime()), 0);

        Calendar cal_4 = Calendar.getInstance();
        cal_4.add(Calendar.DATE, -4);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_4.getTime()), 0);

        Calendar cal_3 = Calendar.getInstance();
        cal_3.add(Calendar.DATE, -3);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_3.getTime()), 0);

        Calendar cal_2 = Calendar.getInstance();
        cal_2.add(Calendar.DATE, -2);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_2.getTime()), 0);

        Calendar cal_1 = Calendar.getInstance();
        cal_1.add(Calendar.DATE, -1);
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(cal_1.getTime()), 0);

        Date today = new Date();
        timeMap.put(new SimpleDateFormat("yyyy-MM-dd").format(today), 0);

        return timeMap;
    }

    // 计算热度同比
    public String calaNewsChange(HashMap<String, Integer> timeMap) {

        // 昨天和今天
        String toDay = new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
        Calendar cal_1 = Calendar.getInstance();
        cal_1.add(Calendar.DATE, -1);
        String yesDay = new SimpleDateFormat("yyyy-MM-dd").format(cal_1.getTime());
        if (timeMap.get(yesDay) == 0) {
            return "--";
        }

        // 计算现在的小时数
        Date now = new Date();
        SimpleDateFormat df = new SimpleDateFormat("HH");
        String hourNumStr = df.format(now);
        float hourNum = Integer.parseInt(hourNumStr);

        // 估算今天一天的新闻量并计算变化量
        float change = (float) (timeMap.get(toDay) * (24 / (hourNum + 0.5)) - timeMap.get(yesDay)) / (timeMap.get(yesDay));
        NumberFormat nt = NumberFormat.getPercentInstance();    // 数字格式化
        nt.setMinimumFractionDigits(0); // 设置小数位数为0

        return nt.format(change);
    }

    // 将查询结果持久化
    public void writeNewsToFile(List<String> newsList) throws FileNotFoundException {
        String filename = "E:\\IDEA Projects\\SerchAllNews\\a.txt";
        PrintWriter writer = new PrintWriter(new File(filename));
        newsList.get(0);
        for (String line : newsList) {
            if (newsList.size() > 100) {

            }
            writer.write(line);
            writer.write("\n");
        }
        writer.close();
    }

    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        SearchAllNews news = new SearchAllNews();
        try {
            news.writeNewsToFile(news.showSearchResult(""));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - start) + "毫秒");
    }
}

