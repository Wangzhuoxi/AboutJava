# encoding: utf-8

from pykafka import KafkaClient


class KafkaConn():

    client = None
    topic = None

    # 连接
    def set_client(self, hosts):
        self.client = KafkaClient(hosts=str(hosts))

    # topic
    def set_topic(self, queueName):
        self.topic = self.client.topics[str(queueName)]

    # 消息
    def put_queue(self, message):
        # get_sync_producer同步消息（需要确认比较慢）
        with self.topic.get_sync_producer() as producer:
            producer.produce(str(message))