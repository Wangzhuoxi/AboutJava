# -*- coding: utf-8 -*-
import datetime
import os
import re
from scrapy.contrib.spiders import CrawlSpider,Rule
from scrapy.contrib.linkextractors import LinkExtractor
from demo.items import NewsSpiderItem
from BloomFilter import BloomFilter
from getcontent import GetContent

class NewsSpider(CrawlSpider):
    # 爬虫的唯一名称，通过这个名字启动
    name = 'news'

    # 开始的URL
    start_urls = ['http://news.163.com/']

    # 时间定义(新闻的URL中都带有时间参数，如19/0416代表新闻是2019年4月16日的)
    now = datetime.datetime.now()
    a = now.strftime('%Y%m%d')
    year = a[2:4]
    md = a[4:8]
    b = year + '/' + md

    # 定义爬取的规则元组（提取链接）
    # LinkExtractor按照allow规则从网页中抽取会被跟进的链接对象
    # Rule定义爬取规则，callback针对每一个response调用，follow提取的链接是否跟进
    rules = (
        Rule(LinkExtractor(allow=r'163.com/' + b + "/"),
             callback = "parse_news", follow = True),
    )

    # 回调函数,处理response
    def parse_news(self, response):
        # 定义item
        item = NewsSpiderItem()
        url = response.url

        # 布隆过滤器类
        bf = BloomFilter(500000, 7)

        # 过滤器路径
        path = os.path.abspath(".").replace('\\','/')
        path += '/bloom_filter_url.txt'
        open(path,'a') # a-追加模式

        # 爬取过的链接会保存到bloom_filter_url.txt中避免重复爬取
        lines = open(path).read().splitlines()
        for line in lines:
            bf.add(line)

        # 过滤器文件
        fp = open(path,'a')

        # 新的链接没有爬取过
        if bf.lookup(url) == "Nope":
            # 写入过滤器文件
            fp.write(url + "\n")

            # 获取内容，返回的是数据列表
            gc = GetContent();
            r = gc.get(str(response.url))

            # 从结果中获取数据
            news_url = response.url
            news_body = r[4]
            news_title = r[2]
            date = r[0]

            # 当前日期的有效数据
            if date == datetime.datetime.now().strftime('%Y%m%d'):
                # 正则表达式
                partten = re.compile(r"(\d{4})(\d{2})(\d{2})")
                res = partten.search(str(date)).groups()
                if len(res) >= 3:
                    year = res[0]
                    month = res[1]
                    day = res[2]
                news_time = year + '-' + month + '-' + day

            # 数据添加到item
            if news_url:
                item['news_url'] = news_url
            if news_title:
                item['news_title'] = str(news_title).strip()
            if news_body:
                item['news_body'] = news_body.strip().replace(" ", "").replace("\"", "“").strip('\n').strip('\r').strip(
                    '\r\n').replace("\r", "").replace("\n", "").replace("\r\n", "")
            if news_time:
                item['news_time'] = news_time

        # 关闭过滤器文件
        fp.close()
        return item


