# encoding: utf-8
import re
import urllib
import html2text
import socket
import string
from readability.readability import Document

import sys

reload(sys)
sys.setdefaultencoding('GBK')

# socket超时时间
timeout = 300
socket.setdefaulttimeout(timeout)


# 获取日期
def find_date(contents):
    line_contain_year = []
    lines = contents.lower().strip().split('\n')

    # 日期的各种格式处理
    # 中国日期格式
    cn_year_pattern = re.compile(r'20[0-9]{2}年')
    cn_month_pattern = re.compile(r'[0-1][0-9]月')
    cn_day_pattern = re.compile(r'[0-3][0-9]日')

    # 国际日期格式
    year_pattern = re.compile(r'20[0-9]{2}')
    month_pattern = re.compile(
        r'(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)')
    day_pattern = re.compile(r'[0-3][0-9]')

    # 其他日期格式
    date_pattern1 = re.compile(r'20[0-1][0-9][-_,/]{0,}[0-1][0-9][-_,/]{0,}[0-3][0-9]')
    date_pattern3 = re.compile(r'20[0-1][0-9][-_,/]{0,}[0-9][-_,/]{0,}[0-3][0-9]')
    date_pattern4 = re.compile(r'20[0-1][0-9][-_,/]{0,}[0-1][0-9][-_,/]{0,}[0-9]')
    date_pattern5 = re.compile(r'20[0-1][0-9][-_,/]{0,}[0-9][-_,/]{0,}[0-9]')
    date_pattern2 = re.compile(r'[0-1][1-9][-_,/]{0,}[0-3][0-9][-_,/]{0,}20[0-1][0-9]')
    date_pattern6 = re.compile(r'[1-9][-_,/]{0,}[0-3][0-9][-_,/]{0,}20[0-1][0-9]')
    date_pattern7 = re.compile(r'[0-1][1-9][-_,/]{0,}[0-9][-_,/]{0,}20[0-1][0-9]')
    date_pattern8 = re.compile(r'[1-9][-_,/]{0,}[0-9][-_,/]{0,}20[0-1][0-9]')

    # 查询到的所有日期结果
    all_date = []
    for line in lines:
        if len(date_pattern1.findall(line)) > 0:
            date_result = date_pattern1.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            all_date.append(date_result)
        elif len(date_pattern3.findall(line)) > 0:
            date_result = date_pattern3.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[:4] + '0' + date_result[4:]
            all_date.append(result)
        elif len(date_pattern4.findall(line)) > 0:
            date_result = date_pattern4.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[:6] + '0' + date_result[6:]
            all_date.append(result)
        elif len(date_pattern5.findall(line)) > 0:
            date_result = date_pattern5.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[:4] + '0' + date_result[4:]
            date_result = result
            result = date_result[:6] + '0' + date_result[6:]
            all_date.append(result)
        elif len(date_pattern2.findall(line)) > 0:
            date_result = date_pattern2.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[4:] + date_result[0:4]
            all_date.append(result)
        elif len(date_pattern6.findall(line)) > 0:
            date_result = date_pattern6.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[4:] + date_result[0:4]
            result = result[:4] + '0' + result[4:]
            all_date.append(result)
        elif len(date_pattern7.findall(line)) > 0:
            date_result = date_pattern7.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[4:] + date_result[0:4]
            result = result[:6] + '0' + result[6:]
            all_date.append(result)
        elif len(date_pattern8.findall(line)) > 0:
            date_result = date_pattern8.findall(line)[0]
            date_result = date_result.replace('-', '').replace(',', '').replace('/', '').replace('_', '')
            result = date_result[4:] + date_result[0:4]
            result = result[:4] + '0' + result[4:]
            result = result[:6] + '0' + result[6:]
            all_date.append(result)
        elif len(cn_year_pattern.findall(line)) > 0:
            year = cn_year_pattern.findall(line)[0]
            if len(cn_month_pattern.findall(line)) > 0:
                month = cn_month_pattern.findall(line)[0]
                if len(cn_day_pattern.findall(line)) > 0:
                    day = cn_day_pattern.findall(line)[0]
                    date_result = year + month + day
                    all_date.append(date_result)
        elif len(year_pattern.findall(line)) > 0:
            year = year_pattern.findall(line)[0]
            if len(month_pattern.findall(line)) > 0:
                month = month_pattern.findall(line)[0]
                month_bak = month
                month_pos = -1
                if month.find('jan') != -1:
                    month = '01'
                if month.find('feb') != -1:
                    month = '02'
                if month.find('mar') != -1:
                    month = '03'
                if month.find('apr') != -1:
                    month = '04'
                if month.find('may') != -1:
                    month = '05'
                if month.find('jun') != -1:
                    month = '06'
                if month.find('jul') != -1:
                    month = '07'
                if month.find('aug') != -1:
                    month = '08'
                if month.find('sep') != -1:
                    month = '09'
                if month.find('oct') != -1:
                    month = '10'
                if month.find('nov') != -1:
                    month = '11'
                if month.find('dec') != -1:
                    month = '12'
                month_pos = line.find(month_bak)
                year_pos = line.find(year)
                if year_pos > month_pos:
                    first = month_pos
                    last = year_pos
                    step_length = len(month_bak)
                else:
                    first = year_pos
                    last = month_pos
                    step_length = len(year)
                try:
                    day = day_pattern.findall(line[first + step_length:last])[0]
                except:
                    try:
                        day = day_pattern.findall(line[:last])[0]
                    except:
                        day = '01'
                # 日期存入返回结果
                date_result = year + month + day
                all_date.append(date_result)

    if len(all_date) > 0:
        return all_date[0]
    return ''


class GetContent():

    # 获取数据
    def get(self, url):
        result = []
        try:
            url = url

            # 创建一个表示远程url的类文件对象，然后像本地文件一样操作这个类文件对象来获取远程数据。
            request = urllib.urlopen(url)
            html = request.read()   # html页面
            request.close()

            doc = Document(html)
            con = doc.content()
            contents = html2text.html2text(con) # 网站内容

            # 处理数据
            title = self.get_title(doc).encode('utf-8').split('|')[0].split('_')[0].replace('\'', '`')
            text = self.get_text(doc).encode('utf-8').replace('\'', '`')
            time = self.find_time(contents).decode('utf8', 'ignore').encode('utf-8')
            date = ''

            # 从time中获取日期date
            if len(time) > 8:
                pattern = re.compile('20[0-1][0-9]-[0-1][0-9]-[0-3][0-9] [0-2][0-9]:[0-6][0-9]:[0-6][0-9]')
                if len(pattern.findall(time)) > 0:
                    tt = time.split(' ')[0].split('-')
                    year = tt[0]
                    month = tt[1]
                    if len(month) < 2:
                        month = '0' + month
                    day = tt[2]
                    if len(day) < 2:
                        day = '0' + day
                    # date赋值
                    date = year + month + day
                else:
                    time = '1700-01-01 01:00:00'
            elif len(time) < 1:
                time = '1587-01-01 01:00:00'

            month_pattern = re.compile(r'\d{4}-(\d{2})-\d{2}')
            day_pattern = re.compile(r'\d{4}-\d{2}-(\d{2})')

            month = month_pattern.search(time)
            if month:
                month_result = month.group(1)
                month_result = string.atoi(month_result)    #atoi：字符串转整数
                if month_result > 12:
                    time = '1700-01-01 01:00:00'

            day = day_pattern.search(time)
            if day:
                day_result = day.group(1)
                day_result = string.atoi(day_result)
                if day_result > 30:
                    time = '1700-01-01 01:00:00'

            # 多种途径获取日期
            if len(date) < 1:
                date = find_date(url)
                if len(date) < 8:
                    date = find_date(con)

            # 获取作者（未使用）
            author = self.get_author(contents)

            # 添加到返回结果中
            result.append(str(date))    #日期（XXXX-XX-XX）
            result.append(str(author))
            result.append(str(title))   #标题
            result.append(str(time))
            result.append(str(text))    #内容
        except:
            print 'throw exception'
        finally:
            return result

    # 获取标题
    def get_title(self, doc):
        readable_title = doc.short_title()
        return readable_title

    # 获取内容
    def get_text(self, doc):
        sum = doc.summary()
        text = html2text.html2text(sum)
        return text

    # 查找时间（根据不同的时间格式分别处理）
    def find_time(self, contents):
        result = ''
        contents = str(" ".join(contents.split()))
        if len(result) < 2:
            pattern = re.compile('20\d+年\d+月\d+日 \d+:\d+:\d+')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split())
                    result_list = result.split(':')
                    pattern_month = re.compile('\d+月')
                    pattern_day = re.compile('\d+日')
                    result = result[0:4] + '-' + pattern_month.findall(result)[0].replace('月', '') + '-' + \
                             pattern_day.findall(result)[0].replace('日', '') + ' ' + result_list[0][-2:] + ':' + \
                             result_list[1] + ":" + result_list[2]

        if len(result) < 2:
            pattern = re.compile('20\d+年\d+月\d+日\d+:\d+:\d+')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split())
                    result_list = result.split(':')
                    pattern_month = re.compile('\d+月')
                    pattern_day = re.compile('\d+日')
                    result = result[0:4] + '-' + pattern_month.findall(result)[0].replace('月', '') + '-' + \
                             pattern_day.findall(result)[0].replace('日', '') + ' ' + result_list[0][-2:] + ':' + \
                             result_list[1] + ":" + result_list[2]

        if len(result) < 2:
            pattern = re.compile('20\d{2}年\d+月\d+日 \d{2}:\d{2}')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split())
                    result_list = result.split(':')
                    pattern_month = re.compile('\d+月')
                    pattern_day = re.compile('\d+日')
                    result = result[0:4] + '-' + pattern_month.findall(result)[0].replace('月', '') + '-' + \
                             pattern_day.findall(result)[0].replace('日', '') + ' ' + result_list[0][-2:] + ':' + \
                             result_list[1] + ":00"

        if len(result) < 2:
            pattern = re.compile('20\d+年\d+月\d+日')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split())
                    pattern_month = re.compile('\d+月')
                    pattern_day = re.compile('\d+日')
                    result = result[0:4] + '-' + pattern_month.findall(result)[0].replace('月', '') + '-' + \
                             pattern_day.findall(result)[0].replace('日', '') + ' 23:00:00'

        if len(result) < 2:
            pattern = re.compile('20\d{2}年\d+月\d+日 {2}:\d{2}')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split())
                    result_list = result.split(':')
                    pattern_month = re.compile('\d+月')
                    pattern_day = re.compile('\d+日')
                    result = result[0:4] + '-' + pattern_month.findall(result)[0].replace('月', '') + '-' + \
                             pattern_day.findall(result)[0].replace('日', '') + ' ' + result_list[0][-2:] + ':' + \
                             result_list[1] + ":00"

        if len(result) < 2:
            pattern = re.compile('20\d+[-_,.]\d+[-_,.]\d+ \d{2}:\d{2}:\d{2}')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split()).replace('_', '-').replace(',', '-').replace(',','-').replace('.', '-')
                    result_list = result.split(':')
                    date_list = result_list[0].split('-')
                    result = date_list[0] + '-' + date_list[1] + '-' + date_list[2][0:len(date_list[2]) - 2] + ' ' + \
                             result_list[0][-2:] + ':' + result_list[1] + ":" + result_list[2]

        if len(result) < 2:
            pattern = re.compile('20\d+[-_,.\]\d+[-_,.]\d+ \d{2}:\d{2}')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split()).replace('_', '-').replace(',', '-').replace(',','-').replace('.', '-')
                    result_list = result.split(':')
                    date_list = result_list[0].split('-')
                    result = date_list[0] + '-' + date_list[1] + '-' + date_list[2][0:len(date_list[2]) - 2] + ' ' + \
                             result_list[0][-2:] + ':' + result_list[1] + ":00"

        if len(result) < 2:
            pattern = re.compile('20\d+[-_,.]\d+[-_,.]\d+')
            if len(pattern.findall(contents)) > 0:
                date_result = pattern.findall(contents)
                if len(date_result) > 0:
                    result = "".join(date_result[0].split()).replace('_', '-').replace(',', '-').replace(',','-').replace('.', '-')
                    date_list = result.split('-')
                    result = date_list[0] + '-' + date_list[1] + '-' + date_list[2] + " 23:00:00"
        return result

    # 获取作者（未使用）
    def get_author(self, contents):
        result = ''
        contents = " ".join(contents.split())
        pattern = re.compile(r"来源：(.*)")
        p = pattern.search(str(contents))
        if not p is None:
            res = p.groups()
            result = res[0].split(' ')[0].strip()
            reChinese = re.compile('[\x80-\xff]+')
            chlist = reChinese.findall(result)
            if len(chlist) > 0:
                result = chlist[0]
        if len(result) < 2:
            pattern = re.compile(r"来源： (.*)")
            p = pattern.search(str(contents))
            if not p is None:
                res = p.groups()
                result = res[0].split(' ')[0].strip()
                reChinese = re.compile('[\x80-\xff]+')
                chlist = reChinese.findall(result)
                if len(chlist) > 0:
                    result = chlist[0]
        if len(result) < 2:
            pattern = re.compile(r"来源/作者：(.*)")
            p = pattern.search(str(contents))
            if not p is None:
                res = p.groups()
                result = res[0].split(' ')[0].strip()
                reChinese = re.compile('[\x80-\xff]+')
                chlist = reChinese.findall(result)
                if len(chlist) > 0:
                    result = chlist[0]
        if len(result) < 2:
            pattern = re.compile(r"20[0-9]{2}年[0-1][0-9]月[0-3][0-9]日 \d+:\d+ (.*)")
            p = pattern.search(str(contents))
            if not p is None:
                res = p.groups()
                result = res[0].split(' ')[0].strip()
                reChinese = re.compile('[\x80-\xff]+')
                chlist = reChinese.findall(result)
                if len(chlist) > 0:
                    result = chlist[0]
        if len(result) < 2:
            pattern = re.compile(r"\d+:\d+ \[ (.*)")
            p = pattern.search(str(contents))
            if not p is None:
                res = p.groups()
                result = res[0].split(' ')[0].strip()
                reChinese = re.compile('[\x80-\xff]+')
                chlist = reChinese.findall(result)
                if len(chlist) > 0:
                    result = chlist[0]
        if len(result) < 2:
            pattern = re.compile(r"\d+:\d+ (.*)")
            p = pattern.search(str(contents))
            if not p is None:
                res = p.groups()
                result = res[0].split(' ')[0].strip()
                reChinese = re.compile('[\x80-\xff]+')
                chlist = reChinese.findall(result)
                if len(chlist) > 0:
                    result = chlist[0]
        if len(result) < 2:
            pattern = re.compile(r"20[0-9]{2}年[0-1][0-9]月[0-3][0-9]日 (.*)")
            p = pattern.search(str(contents))
            if not p is None:
                res = p.groups()
                result = res[0].split(' ')[0].strip()
                reChinese = re.compile('[\x80-\xff]+')
                chlist = reChinese.findall(result)
                if len(chlist) > 0:
                    result = chlist[0]
        return result



if __name__ == '__main__':
    gc = GetContent()
    r = gc.get('http://news.sohu.com/20160411/n443875369.shtml')
    print '*********************************************************************'
    print len(r)
    print '*********************************************************************'
    if len(r) >= 1:
        print r[0]  # .decode('utf8','ignore').encode('utf-8')
        print '*********************************************************************'
        print r[1]
        print '*********************************************************************'
        print r[2]  # .decode('utf8','ignore').encode('utf-8')
        print '*********************************************************************'
        print r[3]  # .decode('utf8','ignore').encode('utf-8')
        print '*********************************************************************'
        print r[4].strip().replace(" ", "").replace("\"", "“").strip('\n').strip('\r').replace("\r", "").replace("\n","").replace(
            "\r\n", "").decode('utf8', 'ignore').encode('utf-8')
        print '*********************************************************************'
