# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeliqne to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import sys
from spiders.kafkaConnect import KafkaConn

reload(sys)
sys.setdefaultencoding('utf-8')

# 将打印信息输出在相应的位置下
sys.stdout = open('pipeline_output.txt', 'w')


class NewsSpiderPipeline(object):

    # kafka初始化
    #kc = KafkaConn()
    #kc.set_client("192.168.159.129:9092,192.168.159.130:9092,192.168.159.131:9092")
    #kc.set_topic('hotnews')

    def process_item(self, item, spider):
        url = ''
        if item['news_url']:
            url = item['news_url']

        # strip():删除字符串头尾的空格，也可以指定
        # replace():替换字符
        title = ''
        if item['news_title']:
            title = item['news_title'].strip().replace(" ", "").replace("\"", "“").strip('\n').strip('\r').replace("\r", "").replace("\n", "").replace("\r\n", "")

        bodys = ''
        if item['news_body']:
            bodys = item['news_body'].strip().replace(" ", "").replace("\"", "“").strip('\n').strip('\r').replace("\r", "").replace("\n", "").replace("\r\n", "")

        time = ''
        if item['news_time']:
            time = item['news_time'].strip().replace(" ", "").replace("\"", "“").strip('\n').strip('\r').replace("\r", "").replace("\n", "").replace("\r\n", "")

        # 有效的数据
        if len(bodys) > 0 and len(title) > 0 and len(url) > 0 and len(time) > 0:
            # 格式化输出
            result_str = "{\"title\":\"" + title + "\"," + "\"time\":\"" + time + "\"," + "\"url\":\"" + url + "\"," + "\"bodys\":\"" + bodys + "\"}"
            print result_str

            # 消息放入kafka队列中
            #self.kc.put_queue(result_str)