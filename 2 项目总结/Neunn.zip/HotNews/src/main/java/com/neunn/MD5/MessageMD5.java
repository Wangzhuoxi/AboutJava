package com.neunn.MD5;

import java.security.MessageDigest;

public class MessageMD5 {

    public MessageMD5(){

    }

    public String messageMD5(String message){
        char hexDigits[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        try {
            byte[] btInput = message.getBytes();    // 转换成字节数组
            MessageDigest mdInst = MessageDigest.getInstance("MD5");    // MD5转换器
            mdInst.update(btInput);
            byte[] md = mdInst.digest();    // 转换结果（128bit占16个字节）

            // 128bit转换成十六进制表示的32位
            int length = md.length; // 原始128bit的长度是16（8bit等于1个字节）
            char str[] = new char[length * 2];
            int index = 0;
            for (int i = 0; i < length; i++) {
                byte byte0 = md[i];
                str[index++] = hexDigits[byte0 >>> 4 & 0xf];    // 高4位
                str[index++] = hexDigits[byte0 & 0xf];  // 低4位
            }
            return new String(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
