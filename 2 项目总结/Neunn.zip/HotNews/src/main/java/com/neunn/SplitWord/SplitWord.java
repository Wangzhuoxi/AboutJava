package com.neunn.SplitWord;

import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;

import java.io.IOException;
import java.io.StringReader;

public class SplitWord {

    public SplitWord() {

    }

    public  static String splitWordMethod(String message) throws IOException
    {
        StringBuffer resultMessage = new StringBuffer();
        IKSegmenter ikS = new IKSegmenter(new StringReader(message), true); //true使用智能分词
        Lexeme lex = null;  // 切分的词元
        while((lex = ikS.next())!= null){
            resultMessage.append(lex.getLexemeText() + " ");    //getLexemeText获取词元的文本内容
        }
        return resultMessage.toString();
    }

    public static void main(String[] args) throws IOException {
        String text = "本报讯 基于java语言开发的轻量级的中文分词工具包吐槽";
        System.out.println(splitWordMethod(text));
    }
}
