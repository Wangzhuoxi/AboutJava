package com.neunn.hotNews

import java.util.Date

import com.neunn.MD5.MessageMD5
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.{ConnectionFactory, Put}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.SparkConf
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.collection.mutable.ArrayBuffer
import scala.util.parsing.json.JSON

object HotNews {

  def main(args: Array[String]): Unit = {
    // 参数错误，输出提示并退出
    if (args.length < 4) {
      System.err.println("Usage: KafkaWordCount <zkQuorum> <group> <topics> <numThreads>")
      System.exit(1)
    }

    // spark配置
    val Array(zkQuorum, group, topics, numThreads) = args
    val sparkConf = new SparkConf().setAppName("KafkaWordCount").set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")  // 定义名称和序列化器（KryoSerializer更快）
    val ssc = new StreamingContext(sparkConf, Seconds(10))  // 创建spark streaming(10秒一个批次)
    ssc.checkpoint("checkpoint")  // 设置用于容错的checkpoint

    // 构建输入流，即消费kafka消息并和用于处理数据的spark streaming对接
    val topicMap = topics.split(",").map((_,numThreads.toInt)).toMap  // topic和其对应的分区数的映射（并发线程数量）
    val lines = KafkaUtils.createStream(ssc, zkQuorum, group, topicMap).map(_._2) // 创造一个从kafka broker提取消息的输入流并获取返回二元组的第二个元素

    // map方法对每一个元素进行处理生成info
    val info = lines.map(
      line => {
        val jsonObj = JSON.parseFull(line)  //转换成json
        val map: Map[String, Any] = jsonObj.get.asInstanceOf[Map[String, Any]]
        val urlmd5 = new MessageMD5().messageMD5(map.get("url").get.toString) // 对URL进行MD5加密
        // 根据加密后的url生成唯一的行ID
        val rowKey = new ArrayBuffer[Byte]()
        rowKey ++= Bytes.toBytes(-new Date().getTime())
        rowKey ++= Bytes.toBytes(urlmd5)
        // 生成info信息，即产生的数据
        (rowKey.toArray, map.get("title").get.toString, map.get("bodys").get.toString, map.get("url").get.toString, map.get("time").get.toString)
      }
    )
    info.print

    // 处理Dstream中的每一个批次，将数据存入HBase
    info.foreachRDD(
      rdd => rdd.foreachPartition { // 每一个批次的每一个partition进行处理
        partition =>
          // 连接HBase并获取用户表
          val conf = HBaseConfiguration.create()
          conf.set("hbase.zookeeper.quorum", "192.168.159.129:2181, 192.168.159.130:2181, 192.168.159.131:2181")
          val connection = ConnectionFactory.createConnection(conf)
          val userTable = TableName.valueOf("public_opinion:metadata")
          val table = connection.getTable(userTable)

          // 针对每一个patition中的每一条数据
          partition.foreach{
            element => try {
              // 构造Put对象并存入数据
              val p = new Put(element._1) // 行ID
              p.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("content"), Bytes.toBytes(element._3))
              p.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("url"), Bytes.toBytes(element._4))
              p.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("timestamp"), Bytes.toBytes(element._5))
              p.addColumn(Bytes.toBytes("f2"), Bytes.toBytes("title"), Bytes.toBytes(element._2))
              table.put(p)
            }catch {
              case _: Exception => println("raw error")
            }
          }
          // 关闭用户表和连接
          table.close()
          connection.close()
      }
    )
    // 启动处理程序
    ssc.start()
    ssc.awaitTermination()
  }

}
