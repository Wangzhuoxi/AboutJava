package com.neunn.hotNews

import org.apache.spark.ml.feature.{HashingTF, IDF}
import org.apache.spark.ml.linalg.SparseVector
import org.apache.spark.sql.DataFrame

class HotWordsExtraction {

  def HotWordsExtractionModel(rawdata: DataFrame, NumFeatures: Int, KeywordsNums: Int): Map[Array[Byte], String] = {

    // TF-IDF特征抽取（固定流程）
    val hashingTF = new HashingTF().setInputCol("content").setOutputCol("rawFeatures").setNumFeatures(NumFeatures)
    val featurizedData = hashingTF.transform(rawdata) // 固定长度的特征向量

    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    val idfModel = idf.fit(featurizedData)
    val rescaledData = idfModel.transform(featurizedData)  // 得到每一个单词对应的TF-IDF度量值(越高越能代表本文章)
    rescaledData.show(false) // 文本特征TF-IDF值

    // 处理每一条新闻
    val resultArray = rescaledData.select("label", "content", "features").rdd
      .map(v => (v(0), v(1), v(2).asInstanceOf[SparseVector].indices, v(2).asInstanceOf[SparseVector].values))  // 转换成稀疏向量(索引数组-value数组)
      .map(
        v => {
          val wordArray = v._2.asInstanceOf[Seq[String]]  // 原始文本内容
          val contextArray = v._3.toList  // 特征稀疏矩阵索引
          val valuesArray = v._4.toList   // 特征稀疏矩阵value

          contextArray.foreach(print)
          valuesArray.foreach(print)

          var contextIndex = 0
          var valuesIndex = 0.0

          // 找出特征值最大的索引和value
          for(i <- 0 until contextArray.length - 1){
            if(valuesIndex < valuesArray(i)){
              contextIndex = contextArray(i)
              valuesIndex = valuesArray(i)
            }
          }

          var word = ""
          val contentToHash = new ContentToHash()
          for(msg <- wordArray.distinct){ // 去除重复元素并遍历
            // 找到了关键词
            if(contentToHash.getHashCode(msg, NumFeatures) == contextIndex){
              word = msg
            }
          }
          (v._1, word)  // 添加关键词（label列）
        }
      ).collect()

    // 添加到HashMap中并返回
    var resultMap = Map.empty[Array[Byte], String]
    for(result <- resultArray){
      resultMap += (result._1.asInstanceOf[Array[Byte]] -> result._2)
    }
    resultMap
  }
}
