﻿package chapter_5;

import java.util.ArrayList;

/**
 * 面试题57（一）：和为s的两个数字 
 * 题目：输入一个递增排序的数组和一个数字s，在数组中查找两个数，使得它们的和正好是s。
 * 如果有多对数字的和等于s，输出两个数的乘积最小的。
 */
public class Code_57_01_TwoNumbersWithSum {

	public ArrayList<Integer> FindNumbersWithSum(int [] array,int sum) {
		ArrayList<Integer> res = new ArrayList<>();
		if (array == null || array.length < 2) {
			return res;
		}
		int low = 0;
		int high = array.length - 1;
		while (low < high) {
			if (array[low] + array[high] > sum) {
				high--;
			}else if (array[low] + array[high] < sum) {
				low++;
			}else {
				// 两个数相差越大乘积就越小
				res.add(array[low]);
				res.add(array[high]);
				break;
			}
		}
		return res;
    }
}
