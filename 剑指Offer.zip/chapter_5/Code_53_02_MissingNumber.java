﻿package chapter_5;

/**
 * 面试题53（二）：0到n-1中缺失的数字 
 * 题目：一个长度为n-1的递增排序数组中的所有数字都是唯一的，并且每个数字都在范围0到n-1之内。
 * 在范围0到n-1的n个数字中有且只有一个数字不在该数组中，请找出这个数字。
 */
public class Code_53_02_MissingNumber {

	// 二分法
	public int getMissingNumber(int[] data) {
		int left = 0;
		int right = data.length - 1;
		int mid;
		while (left <= right) {
			mid = left + (right - left) / 2;
			// 目标找到第一个数字和下标不相等的元素
			if (data[mid] == mid) {
				left = mid + 1;// 相等向右找
			} else {
				right = mid - 1;// 不等向左找（丢失的是第一个不等的元素）
			}
		}
		return left;
	}
}
