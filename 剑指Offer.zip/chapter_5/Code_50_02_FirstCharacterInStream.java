﻿package chapter_5;

/**
 * 面试题50（二）：字符流中第一个只出现一次的字符 
 * 题目：请实现一个函数用来找出字符流中第一个只出现一次的字符。
 * 例如，当从字符流中只读出前两个字符"go"时，第一个只出现一次的字符是'g'。
 * 当从该字符流中读出前六个字符"google"时，第一个只出现一次的字符是'l'。
 */
public class Code_50_02_FirstCharacterInStream {

	int[] chars;
	int index;

	public Code_50_02_FirstCharacterInStream() {
		chars = new int[256];
		index = 0;
		for (int i = 0; i < chars.length; i++) {
			chars[i] = -1;
		}
	}

	// 字符流插入一个字符
	public void Insert(char ch) {
		if (chars[ch] == -1) {
			chars[ch] = index; // 第一次出现保存的是出现的下标
		} else if (chars[ch] >= 0) {
			chars[ch] = -2; // 已经重复了，置一个无效的数字
		}
		index++;
	}

	// 返回当前字符流中第一个只出现一次的字符
	public char FirstAppearingOnce() {
		int minIndex = Integer.MAX_VALUE;
		char ch = '#'; // 没有则返回#
		for (int i = 0; i < chars.length; i++) {
			if (chars[i] >= 0 && chars[i] < minIndex) {
				minIndex = chars[i]; // 保证是第一个
				ch = (char) i; // 直接用下标代替字符
			}
		}
		return ch;
	}
}
