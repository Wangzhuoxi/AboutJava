﻿package chapter_5;

/**
 * 面试题51：数组中的逆序对 
 * 题目：在数组中的两个数字如果前面一个数字大于后面的数字，则这两个数字组成一个逆序对。
 * 输入一个数组，求出这个数组中的逆序对的总数。
 */
public class Code_51_InversePairs {

	int count;

	public int InversePairs(int[] array) {
		if (array == null || array.length < 2) {
			return 0;
		}
		count = 0;
		mergeSort(array, 0, array.length - 1);
		return count;
	}

	// 归并排序
	private void mergeSort(int[] array, int start, int end) {
		if (start >= end) {
			return;
		}
		int mid = start + (end - start) / 2;
		mergeSort(array, start, mid);
		mergeSort(array, mid + 1, end);
		merge(array, start, mid, end);
	}

	private void merge(int[] arr, int l, int m, int r) {
		int[] help = new int[r - l + 1];
		int i = 0;
		int p1 = l;		// 左半区
		int p2 = m + 1;	// 右半区
		while (p1 <= m && p2 <= r) {
			count += arr[p1] > arr[p2] ? (m - p1 + 1) : 0;	// 统计逆序对信息
			if (count >= 1000000007) {
				count %= 1000000007;// 额外的取余要求
			}
			help[i++] = arr[p1] < arr[p2] ? arr[p1++] : arr[p2++];
		}
		while (p1 <= m) {
			help[i++] = arr[p1++];
		}
		while (p2 <= r) {
			help[i++] = arr[p2++];
		}
		for (i = 0; i < help.length; i++) {
			arr[l + i] = help[i];
		}
	}
}
