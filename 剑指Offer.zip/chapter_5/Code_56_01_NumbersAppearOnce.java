﻿package chapter_5;

/**
 * 面试题56（一）：数组中只出现一次的两个数字 
 * 题目：一个整型数组里除了两个数字之外，其他的数字都出现了两次。
 * 请写程序找出这两个只出现一次的数字。要求时间复杂度是O(n)，空间复杂度是O(1)。
 */
public class Code_56_01_NumbersAppearOnce {

	// 利用了异或操作的性质
	public void FindNumsAppearOnce(int[] array, int num1[], int num2[]) {
		int result = 0;
		for (int i = 0; i < array.length; i++) {
			result ^= array[i];// 全体异或
		}
		int indexOf1 = findFirstBit1(result);
		if (indexOf1 < 0) {
			return;// 不包含只出现一次的数字
		}
		for (int i = 0; i < array.length; i++) {
			if ((array[i] & indexOf1) == 0) {	//index位是0的一组
				num1[0] ^= array[i];
			} else {	//index位是1的一组
				num2[0] ^= array[i];
			}
		}
	}

	// 找到num的二进制表示中最右是1的一位
	private int findFirstBit1(int num) {
		if (num < 0) {
			return -1;
		}
		int indexOf1 = 1;
		while (num != 0) {
			if ((num & 1) == 1) {
				return indexOf1;// 找到1的位置
			} else {
				num = num >> 1;// 右移
				indexOf1 *= 2; // 索引相应的左移（是将1左移最后结果是二进制只包含1个1的数）
			}
		}
		return -1;
	}
}
