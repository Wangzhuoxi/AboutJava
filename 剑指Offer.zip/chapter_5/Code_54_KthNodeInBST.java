﻿package chapter_5;

/**
 * 面试题54：二叉搜索树的第k个结点 
 * 题目：给定一棵二叉搜索树，请找出其中的第k大的结点。
 */
public class Code_54_KthNodeInBST {

	public class TreeNode {
		int val = 0;
		TreeNode left = null;
		TreeNode right = null;

		public TreeNode(int val) {
			this.val = val;
		}
	}

	private int kth = 0;

	public TreeNode KthNode(TreeNode pRoot, int k) {
		if (pRoot == null || k <= 0) {
			return null;
		}
		TreeNode result = KthNode(pRoot.left, k);
		if (kth == k) {
			return result;// 左子树已经找到，递归返回
		}
		if (++kth == k) {	//进行了递增操作
			return pRoot;// 根节点
		}
		result = KthNode(pRoot.right, k);// 右子树查找
		return result;// 返回最后的结果
	}
}
