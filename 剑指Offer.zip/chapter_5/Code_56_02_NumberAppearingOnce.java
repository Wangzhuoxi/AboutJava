﻿package chapter_5;

/**
 * 面试题56（二）：数组中唯一只出现一次的数字 
 * 题目：在一个数组中除了一个数字只出现一次之外，其他数字都出现了三次。 
 * 请找出那个吃出现一次的数字。
 */
public class Code_56_02_NumberAppearingOnce {

	// 异或操作：两个数字的每一位对应进行加法后对2取模
	// 出现三次：改为对3取模
	public int findNumberAppearOnce(int[] data) {
		if (data == null || data.length < 3) {
			return 0;
		}
		int[] bitSum = new int[32]; // 每一个bit的状态
		int k = 3;
		for (int i = 0; i < data.length; i++) {
			int indexOfBit1 = 1;
			// 针对每一个数
			for (int j = 31; j >= 0; j--) {
				if ((data[i] & indexOfBit1) != 0) {
					bitSum[j] += 1;
				}
				indexOfBit1 <<= 1; // 左移一位
			}
		}
		int result = 0;
		for (int i = 0; i < 32; i++) {
			result <<= 1;
			result += bitSum[i] % k; // 出现三次的最后会变为0
		}
		return result;
	}
	
}
