﻿package chapter_5;

import java.util.Deque;
import java.util.LinkedList;

/**
 * 面试题59（二）：队列的最大值 
 * 题目：请定义一个队列并实现函数max得到队列里的最大值。要求函数max、push_back和pop_front的时间复杂度都是o(1)
 */
public class Code_59_02_QueueWithMax {

	public static class QueueWithMax {
		private Deque<InternalData> queueData;
		private Deque<InternalData> queueMax;
		private int currentIndex;	// 每一个插入队列中的元素索引

		public QueueWithMax() {
			this.queueData = new LinkedList<>();
			this.queueMax = new LinkedList<>();
			this.currentIndex = 0;
		}

		public int max() {
			if (queueMax.isEmpty())
				return 0;
			return queueMax.getFirst().value;
		}

		public void pushBack(int value) {
			InternalData addData = new InternalData(value, currentIndex);
			queueData.addLast(addData);
			
			while (!queueMax.isEmpty() && queueMax.getLast().value < value)
				queueMax.removeLast();
			
			queueMax.addLast(addData);
			currentIndex++;
		}

		public void popFront() {
			if (queueData.isEmpty())
				return;
			InternalData delData = queueData.removeFirst();
			if (delData.index == queueMax.getFirst().index)
				queueMax.removeFirst();
		}

		private class InternalData {
			public int value;
			public int index;

			public InternalData(int value, int index) {
				this.value = value;
				this.index = index;
			}
		}
	}

}
