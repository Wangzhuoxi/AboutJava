﻿package chapter_5;

/**
 * 面试题53（一）：数字在排序数组中出现的次数 
 * 题目：统计一个数字在排序数组中出现的次数。
 * 例如输入排序数组{1, 2, 3, 3, 3, 3, 4, 5}和数字3，由于3在这个数组中出现了4次，因此输出4。
 */
public class Code_53_01_NumberOfK {

	public int GetNumberOfK(int[] array, int k) {
		if (array == null || array.length == 0) {
			return 0;
		}
		int start = getStartOfK(array, k);
		if (start == -1) {
			return 0;
		}
		int end = getEndOfK(array, start, k);
		return end - start + 1;
	}

	// 二分查找
	private int getStartOfK(int[] array, int k) {
		if (k < array[0] || k > array[array.length - 1]) {
			return -1;
		}
		int left = 0;
		int right = array.length - 1;
		int mid;
		while (left <= right) {
			if (left == right) {
				if (array[left] == k) {
					return left;
				} else {
					return -1;
				}
			}
			// 当长度为2，mid取左值
			mid = left + (right - left) / 2;
			if (array[mid] > k) {
				right = mid - 1;
			} else if (array[mid] < k) {
				left = mid + 1;
			} else {
				right = mid; // 相同的值时向左边继续查找第一次出现的下标
			}
		}
		return -1;
	}

	private int getEndOfK(int[] array, int start, int k) {
		if (k < array[0] || k > array[array.length - 1]) {
			return -1;
		}
		int left = start;
		int right = array.length - 1;
		int mid;
		while (left <= right) {
			if (left == right) {
				if (array[left] == k) {
					return left;
				} else {
					return -1;
				}
			}
			// 当长度为2，mid取右值
			mid = left + (right - left + 1) / 2;
			if (array[mid] > k) {
				right = mid - 1;
			} else if (array[mid] < k) {
				left = mid + 1;
			} else {
				left = mid; // 相同的值时向右边继续查找最后一次出现的下标
			}
		}
		return -1;
	}
}
