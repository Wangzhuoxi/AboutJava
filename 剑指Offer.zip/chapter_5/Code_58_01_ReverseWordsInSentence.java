﻿package chapter_5;

/**
 * 面试题58（一）：翻转单词顺序 
 * 题目：输入一个英文句子，翻转句子中单词的顺序，但单词内字符的顺序不变。
 * 为简单起见，标点符号和普通字母一样处理。例如输入字符串"I am a student. "， 则输出"student. a am I"。
 */
public class Code_58_01_ReverseWordsInSentence {

	public String ReverseSentence(String str) {
		if (str == null || str.trim().length() <= 1) {
			return str;
		}
		char[] sentence = str.toCharArray();
		// 翻转整个句子
		reverse(sentence, 0, sentence.length - 1);
		int low = 0;
		int high = 0;
		// 翻转每个单词
		while (low != sentence.length && high != sentence.length) {
			// 找到第一个非空格字符
			while (low != sentence.length && sentence[low] == ' ') {
				++low;
			}
			if (low == sentence.length) {
				break;
			}
			// 找到low后面第一个空格字符
			high = low + 1;
			while (high != sentence.length && sentence[high] != ' ') {
				++high;
			}
			reverse(sentence, low, high - 1);
			low = high + 1;// 继续查找下一个单词
		}
		return new String(sentence);
	}

	// 翻转区间字符
	private void reverse(char[] str, int start, int end) {
		for (int low = start, high = end; low < high; low++, high--) {
			char t = str[low];
			str[low] = str[high];
			str[high] = t;
		}
	}
}
