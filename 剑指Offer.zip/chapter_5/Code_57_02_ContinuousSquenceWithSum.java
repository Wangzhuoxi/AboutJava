﻿package chapter_5;

import java.util.ArrayList;

/**
 * 面试题57（二）：和为s的连续正数序列 
 * 题目：输入一个正数s，打印出所有和为s的连续正数序列（至少含有两个数）。
 * 例如输入15，由于1+2+3+4+5=4+5+6=7+8=15，所以结果打印出3个连续序列1～5、 4～6和7～8。
 */
public class Code_57_02_ContinuousSquenceWithSum {

	// 双指针
	public ArrayList<ArrayList<Integer>> FindContinuousSequence(int sum) {
		if (sum < 3) {
			return new ArrayList<>();
		}
		ArrayList<ArrayList<Integer>> res = new ArrayList<>();
		int low = 1;
		int high = 2;
		int sumOfSequence = low + high;
		while (high <= (sum + 1) / 2) {// 只能存在于[1,(s+1)/2]
			if (sumOfSequence < sum) {
				high++;
				sumOfSequence += high;
			} else if (sumOfSequence > sum) {
				sumOfSequence -= low;
				low++;
			} else {
				ArrayList<Integer> oneOfRes = new ArrayList<>();
				for (int i = low; i <= high; i++) {
					oneOfRes.add(i);
				}
				res.add(oneOfRes);
				high++;
				sumOfSequence += high;
				sumOfSequence -= low;
				low++;
			}
		}
		return res;
	}

}
