﻿package chapter_5;

/**
 * 面试题55（二）：平衡二叉树 
 * 题目：输入一棵二叉树的根结点，判断该树是不是平衡二叉树。
 * 如果某二叉树中任意结点的左右子树的深度相差不超过1，那么它就是一棵平衡二叉树。
 */
public class Code_55_02_BalancedBinaryTree {

	public class TreeNode {
	    int val = 0;
	    TreeNode left = null;
	    TreeNode right = null;

	    public TreeNode(int val) {
	        this.val = val;
	    }
	}
	
	// 利用高度判断是否平衡
	public boolean IsBalanced_Solution(TreeNode root) {
        if (root == null) {
			return true;
		}
        int left = TreeDepth(root.left);
        int right = TreeDepth(root.right);
        if (Math.abs(left - right) > 1) {
			return false;
		}
        return IsBalanced_Solution(root.left) && IsBalanced_Solution(root.right);
    }
	
	// 求二叉树高度
	public int TreeDepth(TreeNode root) {
        if (root == null) {
			return 0;
		}
        int leftDepth = TreeDepth(root.left);
        int rightDepth = TreeDepth(root.right);
        return Math.max(leftDepth, rightDepth) + 1;
    }
	
}
