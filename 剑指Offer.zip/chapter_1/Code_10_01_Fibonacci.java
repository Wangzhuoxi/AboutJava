﻿package chapter_1;

/**
 * 面试题10（一）：斐波那契数列 
 * 题目：写一个函数，输入n，求斐波那契（Fibonacci）数列的第n项。
 */
public class Code_10_01_Fibonacci {

	// 解法一：数据关系
	public int Fibonacci_1(int n) {
		if (n == 0) {
			return 0;
		}
		if (n == 1) {
			return 1;
		}
		int temp1 = 0;
		int temp2 = 1;
		int result = 1;
		for (int i = 2; i <= n; i++) {
			result = temp1 + temp2;
			temp1 = temp2;
			temp2 = result;
		}
		return result;
	}

	// 解法二：递归方法
	public int Fibonacci_2(int n) {
		if (n == 0) {
			return 0;
		}
		if (n == 1) {
			return 1;
		}
		return Fibonacci_2(n - 1) + Fibonacci_2(n - 2);
	}
}
