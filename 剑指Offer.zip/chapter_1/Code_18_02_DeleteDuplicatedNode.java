﻿package chapter_1;

/**
 * 面试题18（二）：删除链表中重复的结点 
 * 题目：在一个排序的链表中，存在重复的结点，请删除该链表中重复的结点，重复的结点不保留，返回链表头指针。
 * 例如，链表1->2->3->3->4->4->5 处理后为 1->2->5
 */
public class Code_18_02_DeleteDuplicatedNode {

	public class ListNode {
		int val;
		ListNode next = null;

		ListNode(int val) {
			this.val = val;
		}
	}

	public ListNode deleteDuplication(ListNode pHead) {
		if (pHead == null || pHead.next == null) {
			return pHead;
		}
		ListNode preNode = new ListNode(0);// 前一个节点
		ListNode tmp = preNode; // 保存一个新节点防止头节点被删除
		preNode.next = pHead;
		ListNode nowNode = pHead;// 当前节点

		// 遍历链表
		while (nowNode != null) {
			// 判断是否存在重复节点，是否应该删除
			if (nowNode.next != null && nowNode.val == nowNode.next.val) {
				while (nowNode.next != null && nowNode.val == nowNode.next.val) {
					nowNode = nowNode.next; // 查找重复值
				}
				preNode.next = nowNode.next; // 删除相应的重复节点
			} else {// 无重复节点直接右移
				preNode = nowNode;
			}
			nowNode = nowNode.next;
		}
		return tmp.next;	//返回头节点
	}
	
}
