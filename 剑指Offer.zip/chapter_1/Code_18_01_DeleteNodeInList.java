﻿package chapter_1;

/**
 * 面试题18（一）：在O(1)时间删除链表结点 
 * 题目：给定单向链表的头指针和一个结点指针，定义一个函数在O(1)时间删除该结点。
 */
public class Code_18_01_DeleteNodeInList {

	public class ListNode {
		int value;
		ListNode next = null;

		ListNode(int val) {
			this.value = val;
		}
	}

	public void deleteNode(ListNode head, ListNode toBeDeleted) {
		if (head == null || toBeDeleted == null) {
			return;
		}
		// 链表中只有一个节点
		if (head == toBeDeleted && head.next == null) {
			head = null;
		} else {
			// 待删除的节点是尾节点
			if (toBeDeleted.next == null) {
				ListNode temp = head;
				while (temp.next != toBeDeleted) { // 找到删除节点的前一个
					temp = temp.next;
				}
				temp.next = null;
			} else { // 待删除的节点不是尾节点
				toBeDeleted.value = toBeDeleted.next.value; // 拷贝下一个节点的value
				toBeDeleted.next = toBeDeleted.next.next;// 拷贝下一个节点的next
			}
		}
	}
	
}
