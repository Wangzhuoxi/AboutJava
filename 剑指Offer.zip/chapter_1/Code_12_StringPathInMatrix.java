﻿package chapter_1;

/**
 * 面试题12：矩阵中的路径 
 * 题目：请设计一个函数，用来判断在一个矩阵中是否存在一条包含某字符串所有字符的路径。
 * 路径可以从矩阵中任意一格开始，每一步可以在矩阵中向左、右、上、下移动一格。如果一条路径经过了矩阵的某一格，那么该路径不能再次进入该格子。
 */
public class Code_12_StringPathInMatrix {

	// 回溯法典型题
	public boolean hasPath(char[] matrix, int rows, int cols, char[] str) {
		if (matrix == null || str == null || matrix.length == 0 || str.length == 0) {
			return false;
		}
		int len = matrix.length;// 此处用一维数组表示矩阵
		boolean[] flags = new boolean[len];// 标记元素是否被访问过

		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				if (matrix[r * cols + c] == str[0]) {// 找到字符串的首字符（很可能不止一个）
					if (hasPath(matrix, rows, cols, r, c, str, 0, flags)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private boolean hasPath(char[] matrix, int rows, int cols, int r, int c, char[] str, int index, boolean[] flags) {
		if (index == str.length) {
			return true; // 匹配到字符串的末尾成功
		}
		if (r >= rows || r < 0 || c >= cols || c < 0) {
			return false; // 遍历出了矩阵的边界false
		}
		if (flags[r * cols + c] == true || matrix[r * cols + c] != str[index]) {
			return false; // 当前矩阵元素已经被访问过或者不等于字符串对应值false
		}
		flags[r * cols + c] = true;// 设置当前元素被访问过
		// 上下左右四个方向遍历
		boolean hp = hasPath(matrix, rows, cols, r + 1, c, str, index + 1, flags)
				|| hasPath(matrix, rows, cols, r - 1, c, str, index + 1, flags)
				|| hasPath(matrix, rows, cols, r, c + 1, str, index + 1, flags)
				|| hasPath(matrix, rows, cols, r, c - 1, str, index + 1, flags);
		if (hp == true) {
			return true;
		}
		// 未返回说明当前行不通，将访问位归位
		flags[r * cols + c] = false;
		return false;
	}

}
