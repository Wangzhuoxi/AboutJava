﻿package chapter_1;

/**
 * 面试题10（三）：变态跳台阶
 * 题目：一只青蛙一次可以跳上1级台阶，也可以跳上2级……它也可以跳上n级。求该青蛙跳上一个n级的台阶总共有多少种跳法。
 */
public class Code_10_03_JumpFloorII {

	// 设跳上n级台阶有f(n)种跳法
	// f(n)种方法包括：(按照最后跳1步分类)
	// 1. 跳上1级台阶后直接跳上n级台阶
	// 2. 跳上2级台阶后直接跳上n级台阶
	// 3. 跳上3级台阶后直接跳上n级台阶
	// 4. ……
	// n-1. 跳上n-1级台阶后直接跳上n级台阶
	// n. 直接跳上n级台阶
	public int JumpFloorII(int target) {
		if (target <= 0) {
			return 0;
		}
		int result = 1;
		// f(n) = f(n-1)+f(n-2)+...+f(2)+f(1) = 2^(n-1) * f(1)
		for (int i = 0; i < target - 1; i++) {
			result *= 2;
		}
		return result;
	}
}
