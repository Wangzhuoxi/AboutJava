﻿package chapter_1;

/**
 * 面试题16：数值的整数次方 
 * 题目：实现函数double Power(double base, int exponent)，求base的exponent次方。
 */
public class Code_16_Power {

	public double Power(double base, int exponent) {
		if (base == 0) {
			return 0; // 底数为0返回0
		}
		if (exponent == 0) {
			return 1; // 指数为0返回1
		}
		// 获取指数的符号
		boolean positive = exponent > 0;
		exponent = positive ? exponent : -exponent;

		// exp可能为负数，负数时先将exp转换成绝对值，求出答案res，最终答案为1/res
		if (positive) {
			return PowerCore(base, exponent);
		} else {
			return 1 / PowerCore(base, exponent);
		}
	}

	// 递归思想：base ^ exp
	// 如果exp为偶数，则拆分成(base ^ (exp/2)) * (base ^ (exp/2))
	// 如果exp为奇数，则拆分成(base ^ (exp/2)) * (base ^ (exp/2)) * base
	private double PowerCore(double base, int exponent) {
		if (exponent == 0) {
			return 1;
		}
		if (exponent == 1) {
			return base;
		}
		double tmp = Power(base, exponent >> 1);

		if ((exponent & 1) == 0) { // exp为偶数
			return tmp * tmp;
		} else {// exp为奇数
			return tmp * tmp * base;
		}
	}
}
