﻿package chapter_1;

/**
 * 面试题15：二进制中1的个数 
 * 题目：请实现一个函数，输入一个整数，输出该数二进制表示中1的个数。
 */
public class Code_15_NumberOf1InBinary {

	// 解法一：循环32次
	public int NumberOf1_1(int n) {
		int count = 0;
		for (int i = 0; i < 32; i++) {
			count += n & 1;// 和1与判断最低位是否位1
			n >>= 1;// 右移一位
		}
		return count;
	}

	// 解法二：循环1的个数次
	// 把一个整数减去1，再和原整数做与运算，会把整数最右边的1变成0。(消耗一个1)
	public int NumberOf1_2(int n) {
		int count = 0;
		while (n != 0) {
			int tmp = n - 1;
			n &= tmp;
			++count;
		}
		return count;
	}
}
