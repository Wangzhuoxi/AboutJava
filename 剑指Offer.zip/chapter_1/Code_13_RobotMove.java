﻿package chapter_1;

/**
 * 面试题13：机器人的运动范围 
 * 题目：地上有一个m行n列的方格。一个机器人从坐标(0, 0)的格子开始移动，它
 * 每一次可以向左、右、上、下移动一格，但不能进入行坐标和列坐标的数位之和大于k的格子。
 */
public class Code_13_RobotMove {

	// 回溯法问题
	public int movingCount(int threshold, int rows, int cols) {
		if (threshold < 0 || rows <= 0 || cols <= 0) {
			return 0;
		}
		boolean[][] visited = new boolean[rows][cols]; // 标志是否被访问过
		return movingCount(threshold, rows, cols, 0, 0, visited);
	}

	private int movingCount(int threshold, int rows, int cols, int r, int c, boolean[][] visited) {
		// 遍历到了边界
		if (r >= rows || r < 0 || c >= cols || c < 0) {
			return 0;
		}
		// 已经被访问过或者不满足条件
		if (visited[r][c] || isBiggerThanThreshold(r, c, threshold)) {
			return 0;
		}
		visited[r][c] = true;// 当前元素满足条件标记未被访问过
		// 向上下左右四个方向遍历
		return 1 + movingCount(threshold, rows, cols, r + 1, c, visited)
				+ movingCount(threshold, rows, cols, r - 1, c, visited)
				+ movingCount(threshold, rows, cols, r, c + 1, visited)
				+ movingCount(threshold, rows, cols, r, c - 1, visited);
	}

	// 判断坐标(r,c)是否满足各数位和不大于阈值
	private boolean isBiggerThanThreshold(int r, int c, int threshold) {
		int sum = 0;
		while (r > 0) {
			sum += r % 10;// 每次取最低位
			r /= 10;
		}
		while (c > 0) {
			sum += c % 10;// 每次取最低位
			c /= 10;
		}
		return sum > threshold;
	}
}
