﻿package chapter_1;

/**
 * 面试题17：打印1到最大的n位数 
 * 题目：输入数字n，按顺序打印出从1最大的n位十进制数。 比如输入3，则打印出1、2、3一直到最大的3位数即999。
 */
public class Code_17_Print1ToMaxOfNDigits {

	// 解法一：全排列方法，递归求解
	public void print1ToMaxOfNDigits_1(int n) {
		if (n <= 0) {
			return;
		}
		char[] digits = new char[n];
		print1ToMaxOfNDigits_1(digits, n - 1);
	}

	private void print1ToMaxOfNDigits_1(char[] digits, int index) {
		if (index == -1) {
			printDigit(digits);// 到达第一位之前就打印
			return;
		}
		// 每一位都由0~9的可能
		for (int i = 0; i < 10; i++) {
			digits[index] = (char) ('0' + i);
			print1ToMaxOfNDigits_1(digits, index - 1);
		}
	}

	// 解法二：递增+进位判断
	public void print1ToMaxOfNDigits_2(int n) {
		if (n <= 0) {
			return;
		}
		char[] digits = new char[n];
		for (int i = 0; i < digits.length; i++) {
			digits[i] = '0';
		}
		while (increment(digits)) {
			printDigit(digits);
		}
	}

	private boolean increment(char[] digits) {
		digits[0] += 1; // 每次加1
		// for循环处理一次的进位
		for (int i = 0; i < digits.length; i++) {
			int num = digits[i] - '0';
			if (num == 10) {
				// 产生了进位但是已经超出了最大范围返回false.
				if (i == digits.length - 1) {
					return false;
				}
				digits[i + 1] += 1;// 产生进位
				digits[i] = '0';
			} else {
				break;
			}
		}
		return true;
	}

	// 打印digits，注意开头不要打印0
	private void printDigit(char[] digits) {
		boolean zeroFlag = true;
		// 主要digtis数组要倒序打印
		for (int i = digits.length - 1; i >= 0; --i) {
			if (digits[i] == '0' && zeroFlag) {
				continue; // 忽略掉开头的0
			}
			System.out.print(digits[i]);
			zeroFlag = false;
		}
		// 打印完每个数后打印一个空格
		if (zeroFlag == false) {
			System.out.print(' ');
		}
	}

}
