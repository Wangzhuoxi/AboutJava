﻿package chapter_1;

/**
 * 面试题10（二）：跳台阶
 * 题目：一只青蛙一次可以跳上1级台阶，也可以跳上2级。求该青蛙跳上一个n级的台阶总共有多少种跳法（先后次序不同算不同的结果）。
 */
public class Code_10_02_JumpFloor {

	// 斐波那契数列问题变形
	public int JumpFloor_1(int target) {
		if (target <= 0) {
			return 0;
		}
		if (target <= 2) {
			return target;
		}
		int temp1 = 1;
		int temp2 = 2;
		int result = 0;
		for (int i = 3; i <= target; i++) {
			result = temp1 + temp2;
			temp1 = temp2;
			temp2 = result;
		}
		return result;
	}
	
	public int JumpFloor_2(int target) {
		if (target == 1) {
			return 1;
		}
		if (target == 2) {
			return 2;
		}
		return JumpFloor_2(target - 1) + JumpFloor_2(target - 2);// 上一步可能是跳1或者跳2，递归思想
	}
}
