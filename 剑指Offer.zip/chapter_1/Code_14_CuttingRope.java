﻿package chapter_1;

/**
 * 面试题14：剪绳子 
 * 题目：给你一根长度为n绳子，请把绳子剪成m段（m、n都是整数，n>1并且m>1）。
 * 每段的绳子的长度记为k[0]、k[1]、……、k[m]。k[0]*k[1]*…*k[m]可能的最大乘积是多少？
 * 例如当绳子的长度是8时，我们把它剪成长度分别为2、3、3的三段，此时得到最大的乘积18。
 */
public class Code_14_CuttingRope {

	// 解法一：动态规划
	// 时间O(n^2)，空间O(n)
	// f(n) = max(f(i), f(n-i))
	public static int cuttingRopeInDynamic(int length) {
		if (length < 2) {
			return 0;
		}
		if (length == 2) {
			return 1;
		}
		if (length == 3) {
			return 2;
		}
		int[] max = new int[length + 1];	// 记录每个长度的最大值
		// 初始值的设定（注意内部不用再切割，最大值就是长度本身）
		max[0] = 0;
		max[1] = 1;
		max[2] = 2;
		max[3] = 3;

		for (int i = 4; i <= length; i++) {
			int maxValue = 0;
			// 注意只用判断一半
			for (int j = 1; j <= i / 2; j++) {
				int temp = max[j] * max[i - j];
				maxValue = temp > maxValue ? temp : maxValue;
			}
			max[i] = maxValue;
		}
		return max[length];
	}

	// 解法二：贪心算法
	// 时间O(1)，空间O(1)
	// 数学证明：
	// 1、当n<5(n=2、3、4)时，我们会发现，无论怎么剪切，乘积product <= n，n为4时，product最大为2*2=4；
	// 2、当n>=5时，可以证明2(n-2)>n并且3(n-3)>n。而且3(n-3)>=2(n-2)。所以我们应该尽可能地多剪长度为3的绳子段。
	public static int cuttingRopeInGreedy(int length) {
		if (length < 2) {
			return 0;
		}
		if (length == 2) {
			return 1;
		}
		if (length == 3) {
			return 2;
		}
		// 尽可能多的剪长度为3的绳子
		int timesOf3 = length / 3;

		// 当绳子最后剩下的长度为4的时候，不能再剪去长度为3的绳子段
		// 此时，更好的方法就是把绳子剪成长度为2的两段，因为2x2>1x3
		if (length - timesOf3 * 3 == 1) {
			timesOf3--;
		}
		int timesOf2 = (length - timesOf3 * 3) / 2;
		return (int) (Math.pow(3, timesOf3) * Math.pow(2, timesOf2));
	}
}
