﻿package chapter_1;

/**
 * 面试题19：正则表达式匹配
 * 题目：请实现一个函数用来匹配包含'.'和'*'的正则表达式。模式中的字符'.'表示任意一个字符，而'*'表示它前面的字符可以出现任意次（含0次）。
 * 在本题中，匹配是指字符串的所有字符匹配整个模式。例如，字符串"aaa"与模式"a.a" 和"ab*ac*a"匹配，但与"aa.a"及"ab*a"均不匹配。
 */
public class Code_19_RegularExpressionsMatching {

	public boolean match(char[] str, char[] pattern) {
		if (str == null || pattern == null) {
			return false;
		}
		return matchCore(str, 0, pattern, 0);
	}

	private boolean matchCore(char[] str, int strIndex, char[] pattern, int pIndex) {
		// 字符串和模式都已匹配完，返回true
		if (strIndex >= str.length && pIndex >= pattern.length) {
			return true;
		}
		// 字符串还没结束，模式已经结束，返回false
		if (strIndex < str.length && pIndex >= pattern.length) {
			return false;
		}
		// 字符串已结束，模式还没结束
		if (strIndex >= str.length && pIndex < pattern.length) {
			// 处理模式的剩余字符(*及其前面的字符出现0次)
			if (pIndex + 1 < pattern.length && pattern[pIndex + 1] == '*') {
				return matchCore(str, strIndex, pattern, pIndex + 2);
			} else {
				return false;
			}
		}
		// 字符串和模式都没处理完的情况
		// 如果模式的下一个字符是*
		if (pIndex + 1 < pattern.length && pattern[pIndex + 1] == '*') {
			// 字符串和模式的当前字符能够匹配
			if (str[strIndex] == pattern[pIndex] || pattern[pIndex] == '.') {
				return matchCore(str, strIndex, pattern, pIndex + 2) // 0次
						|| matchCore(str, strIndex + 1, pattern, pIndex + 2) // 1次
						|| matchCore(str, strIndex + 1, pattern, pIndex);// 多次（不消耗pattern）
			} else {
				// 不匹配则跳过，即出现0次
				return matchCore(str, strIndex, pattern, pIndex + 2);
			}
		} else {// 下一个字符不是*
			// 下一个字符是.
			if (str[strIndex] == pattern[pIndex] || pattern[pIndex] == '.') {
				return matchCore(str, strIndex + 1, pattern, pIndex + 1);
			} else {
				return false;
			}
		}
	}

}
