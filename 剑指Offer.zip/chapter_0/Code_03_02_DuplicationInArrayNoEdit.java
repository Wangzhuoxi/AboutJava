﻿package chapter_0;

/**
 * 面试题3（二）：不修改数组找出重复的数字 
 * 题目：在一个长度为n+1的数组里的所有数字都在1到n的范围内，所以数组中至少有一个数字是重复的。
 * 请找出数组中任意一个重复的数字，但不能修改输入的数组。例如，如果输入长度为8的数组{2, 3, 5, 4, 3, 2, 6,7}，那么对应的输出是重复的数字2或者3。
 */
public class Code_03_02_DuplicationInArrayNoEdit {

	public int getDuplicate(int[] arr) {
		if (arr == null || arr.length <= 0) {
			System.out.println("数组输入无效！");
			return -1;
		}
		for (int a : arr) {
			if (a < 1 || a > arr.length - 1) {
				System.out.println("数字大小超出范围！");
				return -1;
			}
		}
		int low = 1;
		int high = arr.length - 1; // high即为题目的n
		int mid, count;
		// 利用二分查找
		while (low <= high) {
			mid = ((high - low) >> 2) + low;
			count = countRange(arr, low, mid);
			if (low == high) {
				if (count > 1)
					return low;
				else
					break; // 必有重复，应该不会出现这种情况吧？
			}
			if (count > mid - low + 1) {	// 在左半区
				high = mid;
			} else {	// 在右半区
				low = mid + 1;
			}
		}
		return -1;
	}

	// 返回范围内数字的出现次数
	public int countRange(int[] arr, int low, int high) {
        if (arr == null)
            return 0;
 
        int count = 0;
        for (int a : arr) {
            if (a >= low && a <= high)
                count++;
        }
        return count;
    }
}
