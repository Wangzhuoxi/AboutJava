﻿package chapter_0;

/**
 * 面试题8：二叉树的下一个结点
 * 题目： 给定一棵二叉树和其中的一个节点， 如何找出中序遍历的下一个节点？树中的节点除了有两个分别指向左、右节点的指针，还有一个指向父节点的指针
 */
public class Code_08_NextNodeInBinaryTrees {

	public class TreeLinkNode {
		public int val;
		public TreeLinkNode left = null;
		public TreeLinkNode right = null;
		public TreeLinkNode parent = null;

		public TreeLinkNode(int val) {
			this.val = val;
		}
	}

	public TreeLinkNode GetNext(TreeLinkNode pNode) {
		if (pNode == null) {
			return null;
		}
		// 1.右子树不为空
		if (pNode.right != null) {
			return findLeft(pNode.right);
		}
		// 2.右子树为空且是父节点的左孩子
		if (pNode.parent != null && pNode == pNode.parent.left) {
			return pNode.parent;
		}
		// 3.向上遍历查找
		TreeLinkNode cur = pNode;
		while (cur.parent != null && cur != cur.parent.left) {
			cur = cur.parent;
		}
		// 遍历到根节点还是未找到
		if (cur.parent == null) {
			return null;
		}
		return cur.parent;
	}

	// 找到某子树的最左节点
	private TreeLinkNode findLeft(TreeLinkNode pNode) {
		TreeLinkNode cur = pNode;
		while (cur.left != null) {
			cur = cur.left;
		}
		return cur;
	}
}
