﻿package chapter_0;

import java.util.Stack;

/**
 * 面试题9：用两个栈实现队列
 * 题目：用两个栈来实现一个队列，完成队列的Push和Pop操作。 队列中的元素为int类型。
 */
public class Code_09_QueueWithTwoStacks {

	Stack<Integer> stack1 = new Stack<Integer>();// 用来push
	Stack<Integer> stack2 = new Stack<Integer>();// 用来pop

	public void push(int node) {
		stack1.push(node);
	}

	public int pop() {
		// 条件：1.栈2为空 2.一次转移完
		if (stack2.empty()) {
			while (!stack1.isEmpty()) {
				stack2.push(stack1.pop());
			}
		}
		if (stack2.empty())
			throw new RuntimeException("Queue is empty!");
		return stack2.pop();
	}

}
