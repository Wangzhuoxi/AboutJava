﻿package chapter_0;

/**
 * 面试题6：从尾到头打印链表
 * 题目：输入一个链表，按链表值从尾到头的顺序返回一个ArrayList。
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class Code_06_PrintListInReversedOrder {

	public class ListNode {
		int val;
		ListNode next = null;

		ListNode(int val) {
			this.val = val;
		}
	}

	// 解法一：利用Collections的反转方法
	public ArrayList<Integer> printListFromTailToHead_1(ListNode listNode) {
		ArrayList<Integer> arrayList = new ArrayList<>();
		if (listNode == null) {
			return arrayList;
		}
		ListNode cur = listNode;
		while (cur != null) {
			arrayList.add(cur.val);
			cur = cur.next;
		}
		Collections.reverse(arrayList);
		return arrayList;
	}

	// 解法二：利用栈结构
	public ArrayList<Integer> printListFromTailToHead_2(ListNode listNode) {
		ArrayList<Integer> arrayList = new ArrayList<>();
		if (listNode == null) {
			return arrayList;
		}
		Stack<ListNode> stack = new Stack<>();
		while (listNode != null) {
			stack.push(listNode);
			listNode = listNode.next;
		}
		while (!stack.isEmpty()) {
			arrayList.add(stack.pop().val);
		}
		return arrayList;
	}

	// 解法三：递归思路
	// 本质上还是系统栈，当链表很长时有可能导致系统调用栈溢出
	public ArrayList<Integer> printListFromTailToHead_3(ListNode listNode) {
		ArrayList<Integer> arrayList = new ArrayList<>();
		if (listNode == null) {
			return arrayList;
		}
		process(arrayList, listNode);
		return arrayList;
	}

	public void process(ArrayList<Integer> arrayList, ListNode listNode) {
		if (listNode != null) {
			if (listNode.next != null) {
				process(arrayList, listNode.next);//先处理下一个
			}
			arrayList.add(listNode.val);
		}
	}
}
