﻿package chapter_6;

import java.util.Arrays;

/**
 * 面试题61：扑克牌的顺子 
 * 题目：从扑克牌中随机抽5张牌，判断是不是一个顺子，即这5张牌是不是连续的。
 * 2～10为数字本身，A为1，J为11，Q为12，K为13，而大、小王可以看成任意数字。
 */
public class Code_61_ContinousCards {

	public boolean isContinuous(int[] numbers) {
		if (numbers == null || numbers.length == 0) {
			return false;
		}
		Arrays.sort(numbers);
		int num1 = 0;
		int num2 = 0;
		// 统计0（大小王）的个数
		while (num1 != numbers.length && numbers[num1] == 0) {
			num1++;
		}
		// 统计其余数字之间的空缺数
		for (int i = num1 + 1; i < numbers.length; i++) {
			if (numbers[i] == numbers[i - 1]) {
				return false;// 出现了非0的重复数字
			}
			num2 += numbers[i] - numbers[i - 1] - 1;// 空缺数
		}
		if (num1 >= num2) {
			return true;// 大小王能够填补出现的空缺从而组成顺子
		}
		return false;
	}
}
