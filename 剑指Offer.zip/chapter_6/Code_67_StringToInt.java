﻿package chapter_6;

/**
 * 面试题67：把字符串转换成整数 
 * 题目：请你写一个函数StrToInt，实现把字符串转换成整数这个功能。不能使用库函数。
 * 数值为0或者字符串不是一个合法的数值则返回0。
 */
public class Code_67_StringToInt {

	public int StrToInt(String str) {
		if (str == null || str.trim().length() == 0) {
			return 0;
		}
		int index = 0;
		long result = 0;
		boolean isPositive = true;
		// 处理符号位
		if (str.charAt(0) == '+' || str.charAt(0) == '-') {
			index++;
			if (index == str.length()) {
				return 0; // 只有一个符号
			}
			if (str.charAt(0) == '-') {
				isPositive = false;
			}
		}

		for (int i = index; i < str.length(); i++) {
			if (str.charAt(i) < '0' || str.charAt(i) > '9') {
				return 0; // 无效字符
			}
			result *= 10;
			result += (str.charAt(i) - '0') * (isPositive ? 1 : -1);
			if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
				return 0;
			}
		}
		return (int) result;
	}
}
