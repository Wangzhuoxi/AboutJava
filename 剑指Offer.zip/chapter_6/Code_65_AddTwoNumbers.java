﻿package chapter_6;

/**
 * 面试题65：不用加减乘除做加法 
 * 题目：写一个函数，求两个整数之和，要求在函数体内不得使用＋、－、×、÷ 四则运算符号。
 */
public class Code_65_AddTwoNumbers {

	public int Add(int num1, int num2) {
		if (num2 == 0) {
			return num1;
		}
		int sum = 0;
		int carry = 0;// 进位
		while (num2 != 0) {
			sum = num1 ^ num2;// 各个位置相加，不考虑进位
			carry = (num1 & num2) << 1;// 与操作表示需要进位，并向前一位进位
			num1 = sum;
			num2 = carry;
		}
		return num1;
	}
}
