﻿package chapter_6;

/**
 * 面试题66：构建乘积数组 
 * 题目：给定一个数组A[0, 1, …, n-1]，请构建一个数组B[0, 1, …, n-1]，其中B中的元素B[i]
 * =A[0]×A[1]×… ×A[i-1]×A[i+1]×…×A[n-1]。不能使用除法。
 */
public class Code_66_ConstuctArray {

	// 分割成三角形求解
	public int[] multiply(int[] A) {
		if (A == null) {
			return null;
		}
		if (A.length == 0) {
			return new int[0];
		}
		// 下半部分三角形
		int[] result = new int[A.length];
		result[0] = 1;
		for (int i = 1; i < A.length; i++) {
			result[i] = result[i - 1] * A[i - 1];
		}
		// 上半部分三角形
		int tmp = 1;
		for (int i = A.length - 2; i >= 0; i--) {
			tmp *= A[i + 1];
			result[i] *= tmp;
		}
		return result;
	}

}
