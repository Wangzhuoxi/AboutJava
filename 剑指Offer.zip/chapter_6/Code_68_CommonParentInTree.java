﻿package chapter_6;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 面试题68：树中两个结点的最低公共祖先 
 * 题目：输入两个树结点，求它们的最低公共祖先。此树不是二叉树，并且没有指向父节点的指针。
 */
public class Code_68_CommonParentInTree {

	// 普通树节点定义
	public class TreeNode {
		public int val;

		public List<TreeNode> children = new LinkedList<>();

		public TreeNode(int val) {
			this.val = val;
		}
	}

	public TreeNode getLastParent(TreeNode root, TreeNode node1, TreeNode node2) {
		List<TreeNode> path1 = new ArrayList<>();
		List<TreeNode> path2 = new ArrayList<>();
		getPath(root, node1, path1);
		getPath(root, node2, path2);
		TreeNode lastParent = null;
		for (int i = 0; i < path1.size() && i < path2.size(); i++) {
			if (path1.get(i) == path2.get(i)) {
				lastParent = path1.get(i);
			} else {
				break;
			}
		}
		return lastParent;
	}

	// 查找从根节点到node的路径
	public boolean getPath(TreeNode root, TreeNode node, List<TreeNode> path) {
		if (root == node) {
			return true;
		}
		path.add(root);
		// 查找路径
		for (TreeNode child : root.children) {
			if (getPath(child, node, path)) {
				return true;
			}
		}
		path.remove(path.size() - 1);// 回退
		return false;
	}
}
