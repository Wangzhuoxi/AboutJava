﻿package chapter_6;

/**
 * 面试题60：n个骰子的点数 
 * 题目：把n个骰子扔在地上，所有骰子朝上一面的点数之和为s。
 * 输入n，打印出s的所有可能的值出现的概率。
 */
public class Code_60_DicesProbability {

	public void printProbability(int number) {
		if (number <= 0) {
			return;
		}
		final int point = 6;// 骰子最大点数
		// 两个数组分别存储前后两次的结果
		int[][] result = new int[2][6 * number + 1];// 位置0不用
		for (int i = 1; i <= point; i++) {
			result[1][i] = 1;// 投1个骰子的时候1-6都出现一次
		}
		// 投其他骰子
		for (int num = 2; num < number; num++) {// 遍历所有骰子
			// 投出num个骰子，所有和的可能值(num到point*num)
			for (int i = num; i < point * num + 1; i++) {
				// 对应本次的6个值前一次能够取到的结果值
				for (int j = i - 6; j < i; j++) {
					// 有效值
					if (j > 0) {
						// num%2切换上下两个数组
						result[num % 2][i] += result[(num - 1) % 2][j];
					}
				}
			}
		}
		double sum = 0;
		for (int i = number; i < point * number + 1; i++) {
			sum += result[number % 2][i];// 所有和的结果求和
		}
		// 求解概率
		for (int i = number; i < point * number + 1; i++) {
			System.out.println("Probability " + i + ":" + result[number % 2][i] / sum);
		}
	}
}
