﻿package chapter_6;

/**
 * 面试题64：求1+2+…+n 
 * 题目：求1+2+…+n，要求不能使用乘除法、for、while、if、else、switch、case
 * 等关键字及条件判断语句（A?B:C）。
 */
public class Code_64_Accumulate {

	// 整体思路：递归
	public int Sum_Solution(int n) {
		int t = 0;
		// 替换if判断
		@SuppressWarnings("unused")
		boolean b = (n > 0) && ((t = n + Sum_Solution(n - 1)) > 0);	// &&操作符的短路特性
		return t;
	}
}
