﻿package chapter_6;

/**
 * 面试题62：圆圈中最后剩下的数字 
 * 题目：0, 1, …, n-1这n个数字排成一个圆圈，从数字0开始每次从这个圆圈里
 * 删除第m个数字。求出这个圆圈里剩下的最后一个数字。
 */
public class Code_62_LastNumberInCircle {

	class Node {
		public int value;//表示数字的值
		public Node next;

		public Node(int value) {
			this.value = value;
		}
	}

	// 约瑟夫问题
	public int LastRemaining_Solution(int n, int m) {
        if (n < 1 || m < 1) {
			return -1;
		}
        Node head = new Node(0);
        Node cur = head;
        // 初始化环形单链表
        for (int i = 1; i < n; i++) {
			Node node = new Node(i);
			cur.next = node;
			cur = cur.next;
		}
        cur.next = head;
        cur = head;
        
        while (true) {
			if (cur.next == cur) {
				return cur.value;
			}
			// 向后移动
			for (int i = 1; i < m; i++) {
				cur = cur.next;
			}
			// 删除当前节点(通过拷贝下一个)
			cur.value = cur.next.value;
			cur.next = cur.next.next;
			// 删除后，cur停在被删节点的下一个
		}
    }

}
