﻿package chapter_3;

import java.util.ArrayList;
import java.util.TreeSet;

/**
 * 面试题38：字符串的排列 
 * 题目：输入一个字符串，打印出该字符串中字符的所有排列。例如输入字符串abc，
 * 则打印出由字符a、b、c所能排列出来的所有字符串abc、acb、bac、bca、cab和cba。
 */
public class Code_38_StringPermutation {

	TreeSet<String> set;// TreeSet能够去掉重复字符串，并且按字典序排序

	public ArrayList<String> Permutation(String str) {
		if (str == null || str.trim().length() == 0) {
			return new ArrayList<>();
		}
		char[] chars = str.toCharArray();
		set = new TreeSet<>();
		Permutation(chars, 0);
		return new ArrayList<>(set);
	}

	// 字符串的全排列，等于所有可能的首字符，加上剩下的字符的全排列的组合。
	private void Permutation(char[] chars, int index) {
		if (index == chars.length - 1) {
			set.add(new String(chars));
			return;
		}
		for (int i = index; i < chars.length; i++) {
			swap(chars, i, index);	// 交换首字符
			Permutation(chars, index + 1);
			swap(chars, i, index);	// 恢复
		}
	}

	private void swap(char[] chars, int indexA, int indexB) {
		char c = chars[indexA];
		chars[indexA] = chars[indexB];
		chars[indexB] = c;
	}
}
