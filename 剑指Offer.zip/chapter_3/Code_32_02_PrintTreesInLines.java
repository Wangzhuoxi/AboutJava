﻿package chapter_3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

/**
 * 面试题32（二）：分行从上到下打印二叉树 
 * 题目：从上到下按层打印二叉树，同一层的结点按从左到右的顺序打印，每一层打印到一行。
 */
public class Code_32_02_PrintTreesInLines {

	public class TreeNode {
		int val = 0;
		TreeNode left = null;
		TreeNode right = null;

		public TreeNode(int val) {
			this.val = val;
		}
	}

	// 解法一：保存每行的节点数
	ArrayList<ArrayList<Integer>> Print(TreeNode pRoot) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<>();
		if (pRoot == null) {
			return res;
		}
		Queue<TreeNode> queue = new LinkedList<>();
		queue.add(pRoot);

		ArrayList<Integer> linRes = new ArrayList<>();
		int numOfThisLine = 1; // 本行节点数
		int numOfNextLine = 0; // 下一行节点数

		while (!queue.isEmpty()) {
			TreeNode node = queue.poll();
			linRes.add(node.val);
			numOfThisLine--;
			if (node.left != null) {
				queue.add(node.left);
				numOfNextLine++;
			}
			if (node.right != null) {
				queue.add(node.right);
				numOfNextLine++;
			}
			if (numOfThisLine == 0) { // 遍历到行尾
				res.add(linRes);
				linRes = new ArrayList<>();
				numOfThisLine = numOfNextLine;
				numOfNextLine = 0;
			}
		}
		return res;
	}

	// 解法二：保留每一行的最后一个节点
	ArrayList<ArrayList<Integer>> Print_2(TreeNode pRoot) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<>();
		if (pRoot == null) {
			return res;
		}
		Queue<TreeNode> queue = new LinkedList<>();
		queue.add(pRoot);

		ArrayList<Integer> linRes = new ArrayList<>();
		TreeNode last = pRoot; // 本行的最右节点
		TreeNode nLast = null; // 下一行的最右节点

		while (!queue.isEmpty()) {
			TreeNode node = queue.poll();
			linRes.add(node.val);
			if (node.left != null) {
				queue.add(node.left);
				nLast = node.left;
			}
			if (node.right != null) {
				queue.add(node.right);
				nLast = node.right;
			}
			if (node == last) { // 遍历到行尾
				res.add(linRes);
				linRes = new ArrayList<>();
				last = nLast;
			}
		}
		return res;
	}
}
