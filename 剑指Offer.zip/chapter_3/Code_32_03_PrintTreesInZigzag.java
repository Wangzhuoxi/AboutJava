﻿package chapter_3;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;

/**
 * 面试题32（三）：之字形打印二叉树 
 * 题目：请实现一个函数按照之字形顺序打印二叉树，即第一行按照从左到右的顺序打印，
 * 第二层按照从右到左的顺序打印，第三行再按照从左到右的顺序打印， 其他行以此类推。
 */
public class Code_32_03_PrintTreesInZigzag {

	public class TreeNode {
		int val = 0;
		TreeNode left = null;
		TreeNode right = null;

		public TreeNode(int val) {
			this.val = val;
		}
	}

	public ArrayList<ArrayList<Integer>> Print(TreeNode pRoot) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<>();
		if (pRoot == null) {
			return res;
		}
		Deque<TreeNode> deque = new LinkedList<>();
		boolean lr = true;	// 方向标志
		TreeNode last = pRoot;
		TreeNode nLast = null;
		deque.offerFirst(pRoot);
		ArrayList<Integer> curLine = new ArrayList<>();
		while (!deque.isEmpty()) {
			TreeNode node = null;
			if (lr) { // 左到右打印
				node = deque.pollFirst(); // 从头部弹出
				curLine.add(node.val);
				if (node.left != null) {
					nLast = nLast == null ? node.left : nLast; // 确定下一行的最后一个节点
					deque.offerLast(node.left); // 从尾部插入
				}
				if (node.right != null) {
					nLast = nLast == null ? node.right : nLast; // 确定下一行的最后一个节点
					deque.offerLast(node.right); // 从尾部插入
				}
			} else { // 右到左打印
				node = deque.pollLast(); // 从尾部弹出
				curLine.add(node.val);
				if (node.right != null) {
					nLast = nLast == null ? node.right : nLast; // 确定下一行的最后一个节点
					deque.offerFirst(node.right); // 从头部插入
				}
				if (node.left != null) {
					nLast = nLast == null ? node.left : nLast; // 确定下一行的最后一个节点
					deque.offerFirst(node.left); // 从头部插入
				}
			}
			if (node == last) {	//到了行尾
				lr = !lr;
				last = nLast;
				nLast = null;
				res.add(curLine);
				curLine = new ArrayList<>();
			}
		}
		return res;
	}
}
