﻿package chapter_3;

/**
 * 面试题33：二叉搜索树的后序遍历序列 
 * 题目：输入一个整数数组，判断该数组是不是某二叉搜索树的后序遍历的结果。
 * 如果是则返回true，否则返回false。假设输入的数组的任意两个数字都互不相同。
 */
public class Code_33_SquenceOfBST {

	public boolean VerifySquenceOfBST(int[] sequence) {
		if (sequence == null || sequence.length == 0) {
			return false;
		}
		return VerifySquenceOfBST(sequence, 0, sequence.length - 1);
	}

	private boolean VerifySquenceOfBST(int[] sequence, int start, int end) {
		if (start >= end) {
			return true;
		}
		int root = sequence[end]; // 子树根节点
		// 找到右子树的第一个节点
		int index = start;
		for (; index <= end - 1; index++) {
			if (sequence[index] > root) { // 第一个出现的大于根节点的值
				break;
			}
		}
		int preEnd = index - 1;
		int nextStart = index;
		// 看右子树的值是否全部大于根节点
		while (index <= end - 1) {
			if (sequence[index] < root) {
				return false;
			}
			index++;
		}
		return VerifySquenceOfBST(sequence, start, preEnd) && VerifySquenceOfBST(sequence, nextStart, end - 1);
	}
}
