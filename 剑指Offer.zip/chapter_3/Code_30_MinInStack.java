﻿package chapter_3;

import java.util.Stack;

/**
 * 面试题30：包含min函数的栈 
 * 题目：定义栈的数据结构，请在该类型中实现一个能够得到栈的最小元素的min函数。
 * 在该栈中，调用min、push及pop的时间复杂度都是O(1)。
 */
public class Code_30_MinInStack {

	Stack<Integer> stackData = new Stack<>();
	Stack<Integer> stackMin = new Stack<>();	// 栈顶保留当前最小值

	public void push(int node) {
		if (this.stackMin.isEmpty()) {
			this.stackMin.push(node);
		} else if (node <= this.min()) {
			this.stackMin.push(node);
		}
		this.stackData.push(node);
	}

	public void pop() {
		if (this.stackData.isEmpty()) {
			throw new RuntimeException("Your stack is empty.");
		}
		int value = this.stackData.pop();
		if (value == this.min()) {
			this.stackMin.pop();
		}
	}

	public int top() {
		return this.stackData.peek();
	}

	public int min() {
		if (this.stackMin.isEmpty()) {
			throw new RuntimeException("Your stack is empty.");
		}
		return this.stackMin.peek();
	}

}
