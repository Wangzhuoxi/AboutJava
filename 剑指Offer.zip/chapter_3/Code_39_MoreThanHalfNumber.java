﻿package chapter_3;

import java.util.HashMap;
import java.util.Map;

/**
 * 面试题39：数组中出现次数超过一半的数字 
 * 题目：数组中有一个数字出现的次数超过数组长度的一半，请找出这个数字。 
 * 例如输入一个长度为9的数组{1, 2, 3, 2, 2, 2, 5, 4, 2}。由于数字2在数组中出现了5次，超过数组长度的一半，因此输出2。
 */
public class Code_39_MoreThanHalfNumber {

	// 解法一：哈希表
	public int MoreThanHalfNum_Solution_1(int[] array) {
		if (array == null || array.length == 0) {
			return 0;
		}
		if (array.length == 1) {
			return array[0];
		}
		int num = array.length / 2 + 1;	// 半数阈值
		Map<Integer, Integer> map = new HashMap<>();// 记录每一个数字的出现次数
		for (int i : array) {
			if (map.containsKey(i)) {
				int n = map.get(i) + 1;
				if (n >= num) {
					return i;
				}
				map.put(i, n);
			} else {
				map.put(i, 1);
			}
		}
		return 0;
	}

	// 解法二：快速排序思路
	public int MoreThanHalfNum_Solution_2(int[] array) {
		if (array == null || array.length == 0) {
			return 0;
		}
		if (array.length == 1) {
			return array[0];
		}
		int mid = array.length / 2;
		int low = 0;
		int high = array.length - 1;
		int index = partition(array, low, high);
		// 根据index判断在哪个半区继续查找
		while (index != mid) {
			if (index > mid) {
				high = index - 1;
				index = partition(array, low, high);// 在左半区查找
			} else {
				low = index + 1;
				index = partition(array, low, high);// 在右半区查找
			}
		}
		// 验证是否index处元素满足要求
		int res = array[index];
		int count = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] == res) {
				count++;
			}
		}
		return count > mid ? res : 0;
	}

	// 快排思路
	private int partition(int[] arr, int low, int high) {
		int tmp = arr[low]; // 用区间的第一个数作为分隔基数
		while (low < high) {
			while (arr[high] >= tmp && low < high) {
				high--;
			}
			if (low < high) {
				arr[low] = arr[high];
				low++;
			}
			while (arr[low] <= tmp && low < high) {
				low++;
			}
			if (low < high) {
				arr[high] = arr[low];
				high--;
			}
		}
		arr[low] = tmp; // 分割成两个部分
		return low;
	}

	// 解法三：摩尔投票法
	public int MoreThanHalfNum_Solution_3(int[] array) {
		if (array == null || array.length == 0) {
			return 0;
		}
		int res = array[0];
		int times = 1;
		for (int i = 1; i < array.length; i++) {
			if (times == 0) {	// 新值出现
				res = array[i];
				times = 1;
			} else if (array[i] == res) {
				times++;
			} else {
				times--;
			}
		}
		// 验证是否满足要求
		times = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] == res) {
				times++;
			}
		}
		return (times > array.length / 2) ? res : 0;
	}
}
