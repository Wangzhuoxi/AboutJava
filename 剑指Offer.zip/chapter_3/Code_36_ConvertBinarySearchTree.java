﻿package chapter_3;

/**
 * 面试题36：二叉搜索树与双向链表 
 * 题目：输入一棵二叉搜索树，将该二叉搜索树转换成一个排序的双向链表。
 * 要求不能创建任何新的结点，只能调整树中结点指针的指向。
 */
public class Code_36_ConvertBinarySearchTree {

	public class TreeNode {
		int val = 0;
		TreeNode left = null;
		TreeNode right = null;

		public TreeNode(int val) {
			this.val = val;
		}
	}

	TreeNode lastNodeInList = null; // 链表中的最后一个节点

	public TreeNode Convert(TreeNode pRootOfTree) {
		convertNode(pRootOfTree);

		TreeNode head = lastNodeInList;
		while (head != null && head.left != null) {
			head = head.left; // 找到链表头部
		}
		return head;
	}

	// 中序遍历
	private void convertNode(TreeNode node) {
		if (node == null) {
			return;
		}
		TreeNode cur = node;
		if (cur.left != null) {
			convertNode(node.left);
		}
		cur.left = lastNodeInList;
		if (lastNodeInList != null) {
			lastNodeInList.right = cur;
		}
		lastNodeInList = cur;
		if (cur.right != null) {
			convertNode(node.right);
		}
	}
}
