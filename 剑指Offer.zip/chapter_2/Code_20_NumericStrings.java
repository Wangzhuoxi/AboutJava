﻿package chapter_2;

/**
 * 面试题20：表示数值的字符串 
 * 题目：请实现一个函数用来判断字符串是否表示数值（包括整数和小数）。
 * 例如，字符串“+100”、“5e2”、“-123”、“3.1416”及“-1E-16”都表示数值，
 * 但“12e”、“1a3.14”、“1.2.3”、“+-5”及“12e+5.4”都不是
 */
public class Code_20_NumericStrings {

	private int index;// 全局变量表示比较的字符下标

	// 数字有如下两种情况：
	// ①A[.B][e|EC]
	// ②[+|-].B[e|EC]
	// 其中A、C表示数字（带符号或不带符号），B表示不带符号的数字，[]包含的整个部分可有可无。
	public boolean isNumeric(char[] str) {
		if (str == null || str.length == 0) {
			return false;
		}
		index = 0;
		// 判断整数部分
		boolean flag = scanInteger(str);
		// 判断小数部分
		if (index < str.length && str[index] == '.') {
			index++;
			flag = scanUnsignedInteger(str) || flag; // 有可能无整数部分，所以是或操作
		}
		// 判断指数部分
		if (index < str.length && (str[index] == 'e' || str[index] == 'E')) {
			index++;
			flag = scanInteger(str) && flag; // 小数部分是必须的所以是与操作
		}
		return index >= str.length && flag; // 遍历完且flag为true
	}

	// 扫描整数部分
	private boolean scanInteger(char[] str) {
		// 跳过符号位
		if (index < str.length && (str[index] == '+' || str[index] == '-')) {
			index++;
		}
		// 判断剩下的无符号部分
		return scanUnsignedInteger(str);
	}

	// 扫描无符号整数部分
	private boolean scanUnsignedInteger(char[] str) {
		int temp = index;
		while (index < str.length && str[index] >= '0' && str[index] <= '9') {
			index++;
		}
		return index > temp;
	}
}
