﻿package chapter_2;

/**
 * 面试题22：链表中倒数第k个结点 
 * 题目：输入一个链表，输出该链表中倒数第k个结点。
 */
public class Code_22_KthNodeFromEnd {

	public class ListNode {
		int val;
		ListNode next = null;

		ListNode(int val) {
			this.val = val;
		}
	}

	// 先找到第k个，然后让第1和第k同步移动，第k到最后则第1到倒数第k
	public ListNode FindKthToTail(ListNode head, int k) {
		if (head == null || k <= 0) {
			return null;
		}
		ListNode node1 = head;
		ListNode node2 = head;
		// 找到第K个元素，注意下标从1开始
		for (int i = 0; i < k - 1; i++) {
			node1 = node1.next;
			if (node1 == null) {
				return null;
			}
		}
		// 两个指针同步移动
		while (node1.next != null) {
			node1 = node1.next;
			node2 = node2.next;
		}
		return node2;
	}
}
