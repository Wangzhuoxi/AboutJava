﻿package chapter_2;

import java.util.LinkedList;
import java.util.Queue;

/**
 * 面试题27：二叉树的镜像 
 * 题目：请完成一个函数，输入一个二叉树，该函数输出它的镜像。
 */
public class Code_27_MirrorOfBinaryTree {

	public class TreeNode {
		int val = 0;
		TreeNode left = null;
		TreeNode right = null;

		public TreeNode(int val) {
			this.val = val;
		}
	}

	// 解法一：递归实现
	public void Mirror(TreeNode root) {
		if (root == null) {
			return;
		}
		TreeNode tmp = root.left;
		root.left = root.right;
		root.right = tmp;
		// 递归
		Mirror(root.left);
		Mirror(root.right);
	}

	// 解法二：非递归实现（先序遍历）
	public void Mirror_2(TreeNode root) {
		if (root == null) {
			return;
		}
		Queue<TreeNode> queue = new LinkedList<>();
		queue.add(root);
		while (!queue.isEmpty()) {
			TreeNode tmp = queue.poll();
			if (tmp.left != null || tmp.right != null) {
				swap(tmp);
				if (tmp.left != null) {
					queue.add(tmp.left);
				}
				if (tmp.right != null) {
					queue.add(tmp.right);
				}
			}
		}
	}

	// 交换两个节点
	private void swap(TreeNode root) {
		TreeNode tmp = root.left;
		root.left = root.right;
		root.right = tmp;
	}
}
