﻿package chapter_2;

/**
 * 面试题24：反转链表 
 * 题目：定义一个函数，输入一个链表的头结点，反转该链表并输出反转后链表的头结点。
 */
public class Code_24_ReverseList {

	public class ListNode {
		int val;
		ListNode next = null;

		ListNode(int val) {
			this.val = val;
		}
	}

	public ListNode ReverseList(ListNode head) {
		if (head == null || head.next == null) {
			return head;// 长度为0或1
		}
		ListNode pre = null; // 前驱
		ListNode next = null; // 后继
		while (head != null) {
			next = head.next;
			head.next = pre;
			pre = head;
			head = next;
		}
		return pre;
	}
}
