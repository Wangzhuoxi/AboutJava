﻿package chapter_2;

import java.util.ArrayList;

/**
 * 面试题29：顺时针打印矩阵 
 * 题目：输入一个矩阵，按照从外向里以顺时针的顺序依次打印出每一个数字。
 */
public class Code_29_PrintMatrix {

	public ArrayList<Integer> printMatrix(int[][] matrix) {
		ArrayList<Integer> res = new ArrayList<>();
		if (matrix == null || matrix.length == 0) {
			return res;
		}
		int tR = 0;
		int tC = 0;// 左上角
		int dR = matrix.length - 1;
		int dC = matrix[0].length - 1;// 右下角
		while (tR <= dR && tC <= dC) {
			printEdge(matrix, tR++, tC++, dR--, dC--, res);
		}
		return res;
	}

	// 打印子矩阵
	private void printEdge(int[][] matrix, int tR, int tC, int dR, int dC, ArrayList<Integer> res) {
		if (tR == dR) { // 子矩阵只有一行
			for (int i = tC; i <= dC; i++) {
				res.add(matrix[tR][i]);
			}
		} else if (tC == dC) { // 子矩阵只有一列
			for (int i = tR; i <= dR; i++) {
				res.add(matrix[i][tC]);
			}
		} else { // 一般情况
			int curR = tR;
			int curC = tC;
			while (curC != dC) {
				res.add(matrix[tR][curC]);
				curC++;
			}
			while (curR != dR) {
				res.add(matrix[curR][dC]);
				curR++;
			}
			while (curC != tC) {
				res.add(matrix[dR][curC]);
				curC--;
			}
			while (curR != tR) {
				res.add(matrix[curR][tC]);
				curR--;
			}
		}
	}

}
