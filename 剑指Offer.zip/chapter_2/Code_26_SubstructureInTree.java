﻿package chapter_2;

/**
 * 面试题26：树的子结构 
 * 题目：输入两棵二叉树A和B，判断B是不是A的子结构。我们约定空树不是任意一个树的子结构
 */
public class Code_26_SubstructureInTree {

	public class TreeNode {
		int val = 0;
		TreeNode left = null;
		TreeNode right = null;

		public TreeNode(int val) {
			this.val = val;
		}
	}

	public boolean HasSubtree(TreeNode root1, TreeNode root2) {
		if (root1 == null || root2 == null) {
			return false;
		}
		// 对应三种比较
		return check(root1, root2) || HasSubtree(root1.left, root2) || HasSubtree(root1.right, root2);
	}

	// 判断以节点h和节点为t2的子数是否具有相同的结构
	private boolean check(TreeNode h, TreeNode t2) {
		if (t2 == null) {
			return true; // t2树已经比较结束
		}
		if (h == null || h.val != t2.val) {
			return false;
		}
		// h和t2是相等的，继续比较子树
		return check(h.left, t2.left) && check(h.right, t2.right);
	}
}
