﻿package chapter_2;

/**
 * 面试题23：链表中环的入口结点 
 * 题目：一个链表中包含环，如何找出环的入口结点？
 */
public class Code_23_EntryNodeInListLoop {

	public class ListNode {
		int val;
		ListNode next = null;

		ListNode(int val) {
			this.val = val;
		}
	}

	public ListNode EntryNodeOfLoop(ListNode pHead) {
		if (pHead == null || pHead.next == null || pHead.next.next == null) {
			return null;
		}
		ListNode fast = pHead.next.next; // 快走2
		ListNode slow = pHead.next;// 慢走1
		// 有环一定在环上相遇
		while (fast != slow) {
			if (fast.next == null || fast.next.next == null) {
				return null; // 无环
			}
			fast = fast.next.next;
			slow = slow.next;
		}
		fast = pHead; // 快指针重新指回头部
		while (fast != slow) {// 快慢会在入环节点相遇
			fast = fast.next;// 快走1
			slow = slow.next; // 慢走1
		}
		return slow;
	}
}
