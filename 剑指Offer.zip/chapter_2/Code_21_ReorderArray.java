﻿package chapter_2;

import java.util.LinkedList;
import java.util.Queue;

/**
 * 面试题21：调整数组顺序使奇数位于偶数前面
 * 题目：输入一个整数数组，实现一个函数来调整该数组中数字的顺序，使得所有奇数位于数组的前半部分，所有偶数位于数组的后半部分。并保证奇数和奇数，偶数和偶数之间的相对位置不变。
 */
public class Code_21_ReorderArray {

	// 解法一：双指针(!不适合本题，相对顺序会变乱!)
	// 时间：o(N)，空间：o(1)
	public void reOrderArray_1(int[] array) {
		if (array == null || array.length == 0) {
			return;
		}
		int len = array.length;
		int low = 0; // 奇数指针，从前往后遍历
		int high = len - 1;// 偶数指针，从后往前遍历
		while (low <= high) {
			// 从前往后，找到第一个偶数
			while (!isEvent(array[low]) && low <= len - 1) {
				low++;
			}
			// 从后往前，找到第一个奇数
			while (isEvent(array[high]) && high >= 0) {
				high--;
			}
			// low指向偶数，high指向奇数时交换
			if (low <= high) {
				int tmp = array[low];
				array[low] = array[high];
				array[high] = tmp;
			}
		}
	}

	// 判断是偶数还是奇数
	private boolean isEvent(int num) {
		return (num & 1) == 0;
	}

	// 解法二；利用队列
	// 时间：o(N)，空间：o(N)
	public void reOrderArray_2(int[] array) {
		if (array == null || array.length == 0) {
			return;
		}
		Queue<Integer> queue = new LinkedList<>();
		int index = 0;
		for (int val : array) {
			if ((val & 1) == 1) {
				array[index++] = val;// 奇数跳过
			} else {
				queue.add(val);// 偶数添加到队列
			}
		}
		while (index != array.length) {
			array[index++] = queue.poll(); // 偶数添加到后面
		}
	}

	// 解法三：类似插入排序，通过双指针判断
	// 时间：o(N)，空间：o(1)
	public void reOrderArray_3(int[] array) {
		int index = 0;// 奇数的个数
		int len = array.length - 1;
		for (int i = 0; i <= len; i++) {
			if ((array[i] & 1) == 1) {// 遇到奇数
				int j = i;
				while (j > index) {// 不断后移直到遇到上一个奇数
					int temp = array[j];
					array[j] = array[j - 1];
					array[j - 1] = temp;
					j--;
				}
				index++; // 奇数的个数++
			}
			//偶数跳过
		}
	}
}
