﻿package chapter_2;

/**
 * 面试题25：合并两个排序的链表 
 * 题目：输入两个递增排序的链表，合并这两个链表并使新链表中的结点仍然是按照递增排序的。
 */
public class Code_25_MergeSortedLists {

	public class ListNode {
		int val;
		ListNode next = null;

		ListNode(int val) {
			this.val = val;
		}
	}

	public ListNode Merge(ListNode list1, ListNode list2) {
		if (list1 == null || list2 == null) {
			return list1 != null ? list1 : list2;
		}
		ListNode head = list1.val < list2.val ? list1 : list2; // 较小的作为头部
		ListNode cur1 = head == list1 ? list1 : list2; // cur1指向较小链表
		ListNode cur2 = head == list1 ? list2 : list1; // cur2指向较大链表
		ListNode pre = null;
		ListNode next = null;
		while (cur1 != null && cur2 != null) {// 都未到尾部
			if (cur1.val <= cur2.val) {
				pre = cur1;
				cur1 = cur1.next;
			} else {
				next = cur2.next;
				pre.next = cur2;
				cur2.next = cur1;
				pre = cur1;
				cur2 = next;
			}
		}
		pre.next = cur1 == null ? cur2 : cur1; // 剩余的部分直接连接
		return head;
	}
}
