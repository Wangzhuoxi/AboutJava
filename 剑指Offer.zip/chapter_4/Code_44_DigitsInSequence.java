﻿package chapter_4;

/**
 * 面试题44：数字序列中某一位的数字 
 * 题目：数字以0123456789101112131415…的格式序列化到一个字符序列中。在这
 * 个序列中，第5位（从0开始计数）是5，第13位是1，第19位是4，等等。请写一个函数求任意位对应的数字。
 */
public class Code_44_DigitsInSequence {

	public int digitAtIndex(int index) {
		if (index < 0) {
			return -1;
		}
		int digits = 1;	// 位数
		while (true) {
			int digitsNumbers = countOfNumbersFor(digits);
			int countOfNumbers = digitsNumbers * digits;// 一共总数字个数（数字个数x位数）

			if (index < countOfNumbers) {
				// 确定了要找的是digits位数
				return digitAtIndex(index, digits);// 返回查找结果
			} else {
				index -= countOfNumbers;// 减去占掉的数字个数
				digits++;// 移位
			}
		}
	}

	// digits位数的数字个数（如2位数10~99其中含有90个数字）
	private int countOfNumbersFor(int digits) {
		if (digits == 1) {
			return 10;
		}
		int count = (int) Math.pow(10, digits - 1);
		return 9 * count;
	}

	private int digitAtIndex(int index, int digits) {
		// 对应的数值
		int number = beginNumberFor(digits) + index / digits;
		// 从数值右边开始算的位置
		int indexFromRight = digits - index % digits;
		// 去除右边的indexFromRight - 1个数字
		for (int i = 1; i < indexFromRight; i++) {
			number /= 10;
		}
		return number % 10; // 求个位数字
	}

	// digits位数的第一个数字，两位数以10开始，三位数以100开始
	private int beginNumberFor(int digits) {
		if (digits == 1) {
			return 0;
		}
		return (int) Math.pow(10, digits - 1);
	}
}
