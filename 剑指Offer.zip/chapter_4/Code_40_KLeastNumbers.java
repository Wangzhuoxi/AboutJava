﻿package chapter_4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * 面试题40：最小的k个数 
 * 题目：输入n个整数，找出其中最小的k个数。 例如输入4、5、1、6、2、7、3、8
 * 这8个数字，则最小的4个数字是1、2、3、4。
 */
public class Code_40_KLeastNumbers {

	// 解法一：快速排序思路
	public ArrayList<Integer> GetLeastNumbers_Solution(int[] input, int k) {
		if (input == null || input.length == 0 || k <= 0 || k > input.length) {
			return new ArrayList<>();
		}
		ArrayList<Integer> res = new ArrayList<>();
		int low = 0;
		int high = input.length - 1;
		int index = partition(input, low, high);

		while (index != k - 1) {
			if (index > k - 1) {
				high = index - 1;
				index = partition(input, low, high);// 在左半区查找
			} else {
				low = index + 1;
				index = partition(input, low, high);// 在右半区查找
			}
		}

		// 数组的前K个数就是前k小的数
		for (int i = 0; i <= k - 1; i++) {
			res.add(input[i]);
		}
		return res;
	}

	// 将数组分为两部分
	private int partition(int[] arr, int low, int high) {
		int tmp = arr[low]; // 用区间的第一个数作为分隔基数
		while (low < high) {
			while (arr[high] >= tmp && low < high) {
				high--;
			}
			if (low < high) {
				arr[low] = arr[high];
				low++;
			}
			while (arr[low] <= tmp && low < high) {
				low++;
			}
			if (low < high) {
				arr[high] = arr[low];
				high--;
			}
		}
		arr[low] = tmp;
		return low;
	}

	// 解法二：优先级队列（或者红黑树）自带的排序性质
	public ArrayList<Integer> GetLeastNumbers_Solution_2(int[] input, int k) {
		if (input == null || input.length == 0 || k <= 0 || k > input.length) {
			return new ArrayList<>();
		}
		Queue<Integer> queue = new PriorityQueue<>(Collections.reverseOrder());
		for (int i : input) {
			if (queue.size() != k) {
				queue.add(i);
			} else if (queue.peek() > i) {
				queue.poll();
				queue.offer(i);
			}
		}
		return new ArrayList<>(queue);
	}

	// 解法三：堆排序的思想（用数组实现）
	public ArrayList<Integer> GetLeastNumbers_Solution_3(int[] input, int k) {
		if (input == null || input.length == 0 || k <= 0 || k > input.length) {
			return new ArrayList<>();
		}
		ArrayList<Integer> resArrList = new ArrayList<>();
		int[] res = new int[k]; // 保存最小的k个数

		for (int i = 0; i < k; i++) {
			res[i] = input[i]; // 用输入的前k个数初始化
			heapInsert(res, i); // 调整为初始的大根堆
		}
		// 剩余的数插入到堆中并做调整
		for (int i = k; i < input.length; i++) {
			if (input[i] < res[0]) {	//新值小于堆顶替换掉堆顶
				res[0] = input[i];
				heapify(res, 0, k);
			}
		}
		// 转化为ArrayList类型
		for (int i = 0; i < res.length; i++) {
			resArrList.add(res[i]);
		}
		return resArrList;
	}

	// 将index处的值插入到大根堆中
	public void heapInsert(int[] arr, int index) {
		// 子节点 > 父节点进行交换
		while (arr[index] > arr[(index - 1) / 2]) {
			swap(arr, index, (index - 1) / 2);
			index = (index - 1) / 2;
		}
	}

	// 重新调整成大根堆
	public void heapify(int[] arr, int index, int size) {
		int left = index * 2 + 1; // 左孩子
		while (left < size) {
			// 找到左右孩子中的大值
			int largest = left + 1 < size && arr[left + 1] > arr[left] ? left + 1 : left;
			// 子>父，则交换，否则推出循环
			largest = arr[index] < arr[largest] ? largest : index;
			if (largest == index) {	// 满足父>子调整完成
				break;
			}
			swap(arr, largest, index);
			// index向下
			index = largest;
			left = index * 2 + 1;
		}
	}

	// 交换元素
	public void swap(int[] arr, int i, int j) {
		int tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}
	
	// 解法四：利用Arrays的排序算法
	public ArrayList<Integer> GetLeastNumbers_Solution_4(int[] input, int k) {
		if (input == null || input.length == 0 || k <= 0 || k > input.length) {
			return new ArrayList<>();
		}
		ArrayList<Integer> resArrList = new ArrayList<>();
		Arrays.sort(input);	// 升序排序
		
		for (int i = 0; i < k; i++) {
			resArrList.add(input[i]);
		}
		return resArrList;
	}
}
