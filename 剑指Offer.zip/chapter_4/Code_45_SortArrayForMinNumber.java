﻿package chapter_4;

/**
 * 面试题45：把数组排成最小的数
 * 题目：输入一个正整数数组，把数组里所有数字拼接起来排成一个数，打印能拼接出的所有数字中最小的一个。
 * 例如输入数组{3, 32, 321}，则打印出这3个数字能排成的最小数字321323。
 */
import java.util.Comparator;
import java.util.TreeSet;

public class Code_45_SortArrayForMinNumber {

	public String PrintMinNumber(int[] numbers) {
		if (numbers == null || numbers.length == 0) {
			return "";
		}
		// 自定义的红黑树set(定义比较规则)
		TreeSet<String> set = new TreeSet<String>(new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return (o1 + o2).compareTo(o2 + o1) > 0 ? 1 : -1;
			}
		});
		// 利用红黑树的排序性质
		for (int number : numbers) {
			set.add(String.valueOf(number));
		}
		StringBuilder sb = new StringBuilder();
		for (String s : set) {
			sb.append(s);
		}
		return sb.toString();
	}
}
