﻿package chapter_4;

/**
 * 面试题42：连续子数组的最大和 
 * 题目：输入一个整型数组，数组里有正数也有负数。数组中一个或连续的多个整
 * 数组成一个子数组。求所有子数组的和的最大值。要求时间复杂度为O(n)。
 */
public class Code_42_GreatestSumOfSubarrays {

	// 动态规划
	public int FindGreatestSumOfSubArray(int[] array) {
		if (array == null || array.length == 0) {
			return 0;
		}
		int sum = array[0]; // 当前和（相当于dp数组）
		int max = array[0]; // 最大和
		for (int i = 1; i < array.length; i++) {
			sum = sum > 0 ? sum + array[i] : array[i];
			if (sum > max) {
				max = sum;
			}
		}
		return max;
	}
}
