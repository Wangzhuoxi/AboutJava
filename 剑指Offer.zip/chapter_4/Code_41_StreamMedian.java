﻿package chapter_4;

import java.util.Collections;
import java.util.PriorityQueue;

/**
 * 面试题41：数据流中的中位数
 * 题目：如何得到一个数据流中的中位数？ 如果从数据流中读出奇数个数值，那么中位数就是所有数值排序之后位于中间的数值。
 * 如果从数据流中读出偶数个数值，那么中位数就是所有数值排序之后中间两个数的平均值。
 */
public class Code_41_StreamMedian {

	// 优先级队列（改为TreeSet就变为了红黑树）
	PriorityQueue<Integer> maxQ = new PriorityQueue<Integer>(Collections.reverseOrder()); // 大根堆（数值小的区域）
	PriorityQueue<Integer> minQ = new PriorityQueue<Integer>(); // 小根堆（数值大的区域）

	// 读取数据
	public void Insert(Integer num) {
		// 保证大根堆和小根堆大小相等或者大1
		if (((maxQ.size() + minQ.size()) & 1) == 0) { // 偶数个数据
			maxQ.offer(num);// 入大根堆
			minQ.offer(maxQ.remove());// 大根堆顶部元素放到小根堆里
		} else {
			minQ.offer(num);// 入小根堆
			maxQ.offer(minQ.remove());// 小根堆顶部元素放到大根堆里
		}
	}

	// 获取数据的中位数
	public Double GetMedian() {
		if (maxQ.size() == 0 && minQ.size() == 0) {
			return new Double(0.0);
		}
		if (((maxQ.size() + minQ.size()) & 1) == 0) {
			return (double) (minQ.peek() + maxQ.peek()) / 2;
		} else {
			return (double) minQ.peek();
		}
	}
}
