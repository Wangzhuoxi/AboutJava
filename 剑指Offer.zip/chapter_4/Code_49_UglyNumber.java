﻿package chapter_4;

/**
 * 面试题49：丑数 
 * 题目：我们把只包含因子2、3和5的数称作丑数（Ugly Number）。求按从小到
 * 大的顺序的第1500个丑数。例如6、8都是丑数，但14不是，因为它包含因子7。习惯上我们把1当做第一个丑数。
 */
public class Code_49_UglyNumber {

	public int GetUglyNumber_Solution(int index) {
		if (index <= 0) {
			return 0;
		}
		int[] res = new int[index];
		res[0] = 1;	// 习惯定义1是第一个丑数
		int t2 = 0;
		int t3 = 0;
		int t5 = 0;
		// 我们只求丑数，不要去管非丑数
		for (int i = 1; i < index; i++) {
			// 每个丑数必然是由小于它的某个丑数乘以2，3或5得到的
			res[i] = Math.min(res[t2] * 2, Math.min(res[t3] * 3, res[t5] * 5));
			if (res[i] == res[t2] * 2)
				t2++;
			if (res[i] == res[t3] * 3)
				t3++;
			if (res[i] == res[t5] * 5)
				t5++;
		}
		return res[index - 1];
	}
}
