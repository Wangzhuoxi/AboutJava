﻿package chapter_4;

/**
 * 面试题43：从1到n整数中1出现的次数 
 * 题目：输入一个整数n，求从1到n这n个整数的十进制表示中1出现的次数。例如 输入12，从1到12这些整数中包含1
 * 的数字有1，10，11和12，1一共出现了5次。
 */
public class Code_43_NumberOf1 {

	// 解法一：遍历判断
	public int NumberOf1Between1AndN_Solution(int n) {
		int res = 0;
		for (int i = 1; i <= n; i++) {
			res += number1(i);
		}
		return res;
	}

	// 判断数字n是否包含几次1
	private int number1(int n) {
		int res = 0;
		while (n > 0) {
			if (n % 10 == 1) {
				res++;
			}
			n /= 10;
		}
		return res;
	}

	// 解法二：字符串判断
	public int NumberOf1Between1AndN_Solution_2(int n) {
		int res = 0;
		StringBuffer s = new StringBuffer();
		for (int i = 0; i <= n; i++) {	// 所有数字添加到buffer中
			s.append(i);
		}
		String str = s.toString();
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == '1') {
				res++;
			}
		}
		return res;
	}

	// 解法三：归纳法
	public int NumberOf1Between1AndN_Solution_3(int n) {
		int res = 0;
		int cur = 0, before = 0, after = 0;
		int i = 1;
		// 循环判断每一位为1的次数
		while (i <= n) {
			before = n / (i * 10); // 高位
			cur = (n / i) % 10;// 当前位
			after = n - n / i * i;// 低位
			if (cur == 0) {
				// 如果为0，出现1的次数由高位决定，等于高位数字*当前位数（12013）
				res += before * i;
			} else if (cur == 1) {
				// 如果为1，出现1的次数由高位和低位决定，等于高位*当前位+地位+1（12113）
				res += before * i + after + 1;
			} else {
				// 如果大于1，出现1的次数由高位决定，（高位数字+1）*当前位数（12213）
				res += (before + 1) * i;
			}
			i *= 10; // 移位
		}
		return res;
	}
}
