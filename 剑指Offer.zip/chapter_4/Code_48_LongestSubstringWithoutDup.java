﻿package chapter_4;

/**
 * 面试题48：最长不含重复字符的子字符串 
 * 题目：请从字符串中找出一个最长的不包含重复字符的子字符串，计算该最长子
 * 字符串的长度。假设字符串中只包含从'a'到'z'的字符。
 */
public class Code_48_LongestSubstringWithoutDup {

	// 解法一：动态规划
	public int longestSubstringWithoutDup_1(String str) {
		if (str == null || str.length() == 0) {
			return 0;
		}
		// 以每一个位置作为结尾的最长不重复字符长度
		int[] dp = new int[str.length()];
		dp[0] = 1;
		int maxdp = 1;
		for (int dpIndex = 1; dpIndex < dp.length; dpIndex++) {
			int i = dpIndex - 1;// 前一个字符
			// 遍历以前一个字符结尾的最长不重复字符
			for (; i >= dpIndex - dp[dpIndex - 1]; i--) {
				if (str.charAt(dpIndex) == str.charAt(i)) {
					break;// 前一个的最长结构中存在当前值
				}
			}
			dp[dpIndex] = dpIndex - i; // 更新
			maxdp = dp[dpIndex] > maxdp ? dp[dpIndex] : maxdp;
		}
		return maxdp;
	}

	// 解法二：动态规划
	public int longestSubstringWithoutDup_2(String str) {
		// 保存的是字母的位置
		int[] position = new int[26];
		for (int i = 0; i < 26; i++) {
			position[i] = -1;
		}
		int curLen = 1;
		int maxLen = 1;
		position[str.charAt(0) - 'a'] = 0;
		for (int i = 1; i < str.length(); i++) {
			int index = position[str.charAt(i) - 'a'];
			// 当前最大长度不包含本字符
			if (index < 0 || index <= i - 1 - curLen) {
				curLen += 1;
			} else {
				curLen = i - index;	//剔除包含的部分
			}
			if (curLen > maxLen)
				maxLen = curLen;
			position[str.charAt(i) - 'a'] = i;
		}
		return maxLen;
	}
}
